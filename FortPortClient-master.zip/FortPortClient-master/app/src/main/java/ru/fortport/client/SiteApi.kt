package ru.fortport.client

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.webkit.CookieManager
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import android.util.LruCache
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Общий слой для нативных разделов (переписки, друзья): HTTP-клиент с сессией сайта
 * (куки WebView + X-Device-Id), загрузка аватарок с кэшем и фон страницы.
 *
 * Фон: стандартный (assets/styles/bg.webp) или пользовательский — поле profileBackground
 * из /api/users/bio/{id}. Пользовательский скачивается один раз и кэшируется в файл; если он
 * не задан или не скачался — остаётся стандартный (или прошлый закэшированный).
 */
class SiteApi(private val activity: AppCompatActivity) {

    companion object {
        const val ORIGIN = "https://fortport.ru"
        const val HOST = "fortport.ru"
        private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    class Resp(val code: Int, val body: String)

    @Volatile var userId = ""
    @Volatile var deviceId = ""
    @Volatile var userAgent = ""

    // ------------------------------------------------------------------ тестовый режим разработчика

    private val sessionPrefs = activity.getSharedPreferences("fortport_native_session", Context.MODE_PRIVATE)

    /** Не null — тестовый режим: все запросы обслуживает локальная «база» (см. DemoBackend). */
    // Режим не переживает перезапуск: иначе после закрытия приложения в тесте каждый запуск
    // (включая настоящий вход) обслуживался бы локальной «базой». Сами данные теста сохраняются.
    @Volatile var demo: DemoBackend? = null.also { sessionPrefs.edit().putBoolean("demo_mode", false).apply() }
    val isDemo: Boolean get() = demo != null

    fun enterDemo(): DemoBackend {
        val d = demo ?: DemoBackend(activity)
        demo = d
        sessionPrefs.edit().putBoolean("demo_mode", true).apply()
        userId = DemoBackend.ME.toString()
        return d
    }

    fun exitDemo() {
        demo = null
        sessionPrefs.edit().putBoolean("demo_mode", false).apply()
        userId = ""
    }

    /** Один поток для сетевых задач разделов (запросы идут по очереди). */
    val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val imgPool = Executors.newFixedThreadPool(3)

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        // Повтор при обрыве рукопожатия/подключения: за VPN с fake-IP (INCY и т.п.) первое
        // соединение к новому адресу может оборваться (SSLHandshakeException: connection closed),
        // а следующая попытка проходит. Тело запроса при таком сбое ещё не отправлено,
        // поэтому повтор безопасен и для POST.
        .addInterceptor { chain ->
            var attempt = 0
            while (true) {
                try {
                    return@addInterceptor chain.proceed(chain.request())
                } catch (e: javax.net.ssl.SSLHandshakeException) {
                    if (++attempt > 3 || chain.call().isCanceled()) throw e
                } catch (e: java.net.ConnectException) {
                    if (++attempt > 3 || chain.call().isCanceled()) throw e
                } catch (e: java.net.SocketTimeoutException) {
                    // Таймаут может случиться и после отправки тела — повторяем только безопасные методы.
                    val m = chain.request().method
                    if ((m != "GET" && m != "HEAD") || ++attempt > 3 || chain.call().isCanceled()) throw e
                }
                try { Thread.sleep(400L * attempt) } catch (ie: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw java.io.IOException("interrupted", ie)
                }
            }
            @Suppress("UNREACHABLE_CODE")
            throw IllegalStateException()
        }
        .addInterceptor { chain ->
            val req = chain.request()
            if (req.url.host != HOST) return@addInterceptor chain.proceed(req)
            val b = req.newBuilder()
            if (userAgent.isNotBlank()) b.header("User-Agent", userAgent)
            if (deviceId.isNotBlank()) b.header("X-Device-Id", deviceId)
            CookieManager.getInstance().getCookie(ORIGIN)?.let { b.header("Cookie", it) }
            val resp = chain.proceed(b.build())
            val set = resp.headers("Set-Cookie")
            if (set.isNotEmpty()) {
                set.forEach { CookieManager.getInstance().setCookie(ORIGIN, it) }
                CookieManager.getInstance().flush()
            }
            resp
        }
        .build()

    fun setSession(userId: String, deviceId: String, userAgent: String) {
        if (userId.isNotBlank()) this.userId = userId
        if (deviceId.isNotBlank()) this.deviceId = deviceId
        this.userAgent = userAgent
    }

    // ------------------------------------------------------------------ запросы

    fun get(path: String): Resp = send("GET", path, null)

    /** json == null — тело пустое (для POST) или отсутствует (GET/DELETE). */
    fun send(method: String, path: String, json: String?): Resp {
        // Вход настоящим аккаунтом всегда идёт на сервер, даже если тестовый режим остался включённым.
        val realAuth = path.startsWith("/api/login") || path.startsWith("/api/add-email")
        if (!realAuth) demo?.let { return it.handle(method, path, json) }
        val body = when {
            method == "GET" -> null
            json != null -> json.toRequestBody(JSON_TYPE) // в т.ч. DELETE с телом (отмена голоса в опросе)
            method == "DELETE" -> null
            else -> ByteArray(0).toRequestBody(null)
        }
        val req = Request.Builder().url(ORIGIN + path).method(method, body).build()
        return execute(req)
    }

    /** Причина последнего сбоя запроса (класс исключения + сообщение) — для диагностики «Нет связи с сервером». */
    @Volatile var lastError = ""

    private fun execute(req: Request): Resp = try {
        client.newCall(req).execute().use { Resp(it.code, it.body?.string().orEmpty()) }.also { lastError = "" }
    } catch (e: Exception) {
        lastError = "${e.javaClass.simpleName}: ${e.message.orEmpty()}".take(140)
        android.util.Log.w("SiteApi", "${req.method} ${req.url.encodedPath} failed", e)
        throw e
    }

    /** multipart-запрос (новый пост, комментарий, картинка); в тестовом режиме — в локальную «базу». */
    fun sendMultipart(method: String, path: String, body: MultipartBody): Resp {
        demo?.let { return it.handleMultipart(method, path, body) }
        val req = Request.Builder().url(ORIGIN + path).method(method, body).build()
        return execute(req)
    }

    /** 0 — id известен, 1 — нет авторизации, 2 — ошибка сети/сервера. */
    fun ensureUserId(): Int {
        if (userId.isNotBlank()) return if (userId.all { it.isDigit() }) 0 else 2
        val r = get("/api/session/bootstrap")
        // Только 401 считается однозначным отсутствием авторизации.
        // 403 может быть ответом WAF/прав доступа и не должен разлогинивать пользователя.
        if (r.code == 401) return 1
        if (r.code != 200) return 2
        val o = JSONObject(r.body)
        if (!o.optBoolean("authenticated", false)) return 1
        val id = o.optJSONObject("user")?.optLong("id", 0L) ?: 0L
        if (id <= 0) return 2
        userId = id.toString()
        return 0
    }

    /**
     * Подтверждает, что сессия действительно недействительна.
     * Сетевые ошибки, 403 (например, блокировка WAF) и 5xx означают
     * неизвестное состояние, а не выход пользователя.
     */
    fun confirmSessionInvalid(): Boolean = try {
        val r = get("/api/session/bootstrap")
        when {
            r.code == 401 -> true
            r.code != 200 -> false
            else -> {
                val o = JSONObject(r.body)
                o.has("authenticated") && !o.optBoolean("authenticated", false)
            }
        }
    } catch (_: Exception) {
        false
    }

    fun absUrl(path: String): String = when {
        path.startsWith("http") || path.startsWith("file:") -> path
        path.startsWith("/") -> ORIGIN + path
        else -> "$ORIGIN/$path"
    }

    fun str(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k, "")

    // ------------------------------------------------------------------ картинки

    private val imgCache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 16L).toInt().coerceAtLeast(2 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    val defaultAvatar: Bitmap? by lazy {
        try { activity.assets.open("ui/default-avatar.jpg").use { BitmapFactory.decodeStream(it) } }
        catch (e: Exception) { null }
    }

    fun decodeSampled(bytes: ByteArray, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxSide && bounds.outHeight / (sample * 2) >= maxSide) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    // Исходные байты анимированных аватарок (GIF / animated WebP): Drawable нельзя делить между View,
    // поэтому для каждой View декодируем свой из кэшированных байтов.
    private val animCache = object : LruCache<String, ByteArray>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray) = value.size
    }

    private fun showAnimated(iv: ImageView, url: String, bytes: ByteArray): Boolean {
        val d = AnimatedImages.decode(bytes, 256) ?: return false
        if (iv.tag == url) iv.setImageDrawable(d)
        return true
    }

    fun loadAvatar(iv: ImageView, path: String) {
        val url = if (path.isBlank()) null else absUrl(path)
        iv.tag = url
        if (url == null) { iv.setImageBitmap(defaultAvatar); return }
        animCache.get(url)?.let { if (showAnimated(iv, url, it)) return }
        imgCache.get(url)?.let { iv.setImageBitmap(it); return }
        iv.setImageBitmap(defaultAvatar)
        imgPool.execute {
            val bytes = try {
                client.newCall(Request.Builder().url(url).get().build()).execute().use { r ->
                    if (!r.isSuccessful) null else r.body?.bytes()
                }
            } catch (e: Exception) { null } ?: return@execute
            if (AnimatedImages.supported && AnimatedImages.isAnimated(bytes)) {
                // Декодируем в фоне; если ImageDecoder не справился — ниже покажем первый кадр, как раньше.
                val anim = AnimatedImages.decode(bytes, 256)
                if (anim != null) {
                    animCache.put(url, bytes)
                    activity.runOnUiThread { if (!activity.isDestroyed && iv.tag == url) iv.setImageDrawable(anim) }
                    return@execute
                }
            }
            val bmp = decodeSampled(bytes, 256)
            if (bmp != null) {
                imgCache.put(url, bmp)
                activity.runOnUiThread { if (iv.tag == url) iv.setImageBitmap(bmp) }
            }
        }
    }

    /**
     * Картинка поста/награды произвольного размера (до [maxSide] по длинной стороне).
     * Результат кэшируется в памяти; [onResult] вызывается в UI-потоке, если ImageView
     * всё ещё ждёт именно этот адрес (его могли переиспользовать для другой карточки).
     */
    fun loadImage(iv: ImageView, path: String, maxSide: Int, onResult: ((Boolean) -> Unit)? = null) {
        if (path.isBlank()) { onResult?.invoke(false); return }
        val url = absUrl(path)
        val key = "$url@$maxSide"
        iv.tag = key
        imgCache.get(key)?.let { iv.setImageBitmap(it); onResult?.invoke(true); return }
        iv.setImageDrawable(null)
        imgPool.execute {
            val bmp = try {
                if (url.startsWith("file:")) {
                    // Файл тестового режима (медиатека виртуального аккаунта).
                    java.io.File(java.net.URI(url)).takeIf { it.exists() }?.readBytes()?.let { decodeSampled(it, maxSide) }
                } else client.newCall(Request.Builder().url(url).get().build()).execute().use { r ->
                    if (!r.isSuccessful) null else r.body?.bytes()?.let { decodeSampled(it, maxSide) }
                }
            } catch (e: Exception) { null }
            if (bmp != null) imgCache.put(key, bmp)
            activity.runOnUiThread {
                if (activity.isDestroyed || iv.tag != key) return@runOnUiThread
                if (bmp != null) iv.setImageBitmap(bmp)
                onResult?.invoke(bmp != null)
            }
        }
    }

    /** Заголовки для потокового воспроизведения медиа (MediaPlayer/VideoView) с сессией сайта. */
    fun mediaHeaders(): Map<String, String> {
        val h = HashMap<String, String>()
        CookieManager.getInstance().getCookie(ORIGIN)?.let { h["Cookie"] = it }
        if (userAgent.isNotBlank()) h["User-Agent"] = userAgent
        if (deviceId.isNotBlank()) h["X-Device-Id"] = deviceId
        return h
    }

    // ------------------------------------------------------------------ фон

    private val prefs = activity.getSharedPreferences("chats_ui", Context.MODE_PRIVATE)
    private val bgFile = File(activity.cacheDir, "chats_bg.bin")
    private val bgViews = ArrayList<ImageView>()
    private var defaultBackground: Bitmap? = null
    private var customBackground: Bitmap? = null

    /** Подключает ImageView, который показывает фон; вызывать из UI-потока. */
    fun attachBackground(view: ImageView, default: Bitmap?) {
        defaultBackground = default
        bgViews.add(view)
        view.setImageBitmap(customBackground ?: defaultBackground)
        if (customBackground == null && bgFile.exists() && !prefs.getString("bg_path", "").isNullOrEmpty()) {
            io.execute { // показываем закэшированный пользовательский фон сразу, без мигания
                if (customBackground != null) return@execute
                val bmp = try { decodeSampled(bgFile.readBytes(), 1600) } catch (e: Exception) { null }
                if (bmp != null) setCustomBackground(bmp)
            }
        }
    }

    /** Свой фон страницы (пользовательский или стандартный) — чтобы вернуть его после чужого. */
    fun ownBackgroundBitmap(): Bitmap? = customBackground ?: defaultBackground

    fun defaultBackgroundBitmap(): Bitmap? = defaultBackground

    /** Скачивает картинку по пути сайта (из io-потока); null — не удалось. */
    fun downloadBitmap(path: String, maxSide: Int): Bitmap? = try {
        client.newCall(Request.Builder().url(absUrl(path)).get().build()).execute().use { r ->
            if (!r.isSuccessful) null else r.body?.bytes()?.let { decodeSampled(it, maxSide) }
        }
    } catch (e: Exception) { null }

    private fun setCustomBackground(bmp: Bitmap?) {
        activity.runOnUiThread {
            if (activity.isDestroyed) return@runOnUiThread
            customBackground = bmp
            bgViews.forEach { it.setImageBitmap(bmp ?: defaultBackground) }
        }
    }

    /** Сверяет фон с профилем и при необходимости скачивает новый. Только из io-потока. */
    fun refreshBackground() {
        if (ensureUserId() != 0) return
        val r = get("/api/users/bio/$userId")
        if (r.code != 200) return // сеть/сервер — оставляем показанное
        val path = str(JSONObject(r.body), "profileBackground")
        val cachedPath = prefs.getString("bg_path", "").orEmpty()
        if (path.isBlank()) {
            if (cachedPath.isNotEmpty() || bgFile.exists()) {
                bgFile.delete()
                prefs.edit().remove("bg_path").apply()
                setCustomBackground(null)
            }
            return
        }
        if (path == cachedPath && bgFile.exists()) return // уже показан из кэша
        val bytes = client.newCall(Request.Builder().url(absUrl(path)).get().build()).execute().use { resp ->
            if (resp.isSuccessful) resp.body?.bytes() else null
        } ?: return
        val bmp = decodeSampled(bytes, 1600) ?: return // не картинка — остаётся прежний
        bgFile.writeBytes(bytes)
        prefs.edit().putString("bg_path", path).apply()
        setCustomBackground(bmp)
    }

    fun destroy() {
        io.shutdownNow()
        imgPool.shutdownNow()
    }
}
