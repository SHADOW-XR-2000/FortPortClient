package ru.fortport.client

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineView: View
    private lateinit var offlineImage: ImageView
    private var lastLoadFailed = false
    private lateinit var bottomNavBar: LinearLayout
    private lateinit var topNavBar: LinearLayout
    private lateinit var sectionHeader: LinearLayout
    private lateinit var sectionHeaderIcon: ImageView
    private lateinit var sectionHeaderTitle: TextView
    private lateinit var navHomeCenter: ImageButton
    private lateinit var siteApi: SiteApi
    private lateinit var nativeChatsPanel: View
    private lateinit var nativeFriendsPanel: View
    private lateinit var nativeCommunitiesPanel: View
    private lateinit var nativeMusicPanel: View
    private lateinit var nativeFeedPanel: View
    private lateinit var nativePostPanel: View
    private lateinit var nativeProfilePanel: View
    private lateinit var nativePortPanel: View
    private lateinit var nativeNotifsPanel: View
    private lateinit var nativeSettingsPanel: View
    private lateinit var settingsTopBar: View
    private lateinit var settingsController: SettingsController
    private lateinit var notifBottomBar: View
    private lateinit var postTopBar: View
    private lateinit var sectionHeaderAction: ImageButton
    private lateinit var chatsController: ChatsListController
    private lateinit var friendsController: FriendsListController
    private lateinit var communitiesController: CommunitiesListController
    private lateinit var musicController: MusicController
    private lateinit var feedController: FeedController
    private lateinit var postController: PostPageController
    private lateinit var profileController: ProfileController
    private lateinit var portController: PortController
    private lateinit var notifsController: NotificationsController
    private lateinit var loginController: LoginController

    /** Нативные экраны, которые показываются поверх WebView вместо веб-страниц /chats и /friends. */
    private enum class NativeSection { CHATS, FRIENDS, COMMUNITIES, MUSIC, FEED, POST, PROFILE, PORT, NOTIFS, SETTINGS }
    private var nativeSection: NativeSection? = null
    /** Чья музыка откроется в нативной вкладке: null — своя (выставляется при перехвате /music?id=…). */
    private var pendingMusicUserId: String? = null
    /** Открытый пост: какой показать (и, если уже есть, его данные из ленты). */
    private var pendingPostId = 0L
    private var pendingPost: Post? = null
    /** Раздел, из которого открыли пост: «Назад» вернёт в него (лента сохраняет позицию). */
    private var postParent: NativeSection? = null
    /** Пост, из которого ушли в профиль/порт: «Назад» оттуда вернёт к нему. */
    private var postReturnId = 0L
    /** После goBack() к главной не показывать ленту поверх вернувшегося нативного поста. */
    private var skipNativeNavOnce = false
    /** Чей профиль открыт на нативном экране PROFILE (0 — свой). */
    private var pendingProfileId = 0L
    /** Куда вернёт «Назад» из профиля/музыки, открытых из нативных экранов (стек переходов). */
    private class NavFrame(val section: NativeSection, val postId: Long, val postParent: NativeSection?, val profileId: Long, val communityId: Long)
    private val navFrames = ArrayList<NavFrame>()
    /** Профиль, из которого ушли на веб-страницу (порт, друзья, настройки): «Назад» вернёт именно его. */
    private var returnProfileId = 0L
    /** Чей порт открыт на нативном экране PORT. */
    private var pendingCommunityId = 0L
    private var returnPortId = 0L
    /** Чьи друзья/порты показать в нативных списках: null — свои. */
    private var pendingFriendsUserId: String? = null
    private var pendingCommunitiesUserId: String? = null
    private var commentPickCb: ((Uri) -> Unit)? = null
    private val commentPicker =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) commentPickCb?.invoke(uri)
        }
    /** Из нативного списка открыли профиль: «Назад» вернёт в этот список. */
    private var returnSection: NativeSection? = null
    /** Последний известный адрес страницы (в т.ч. после JS-роутинга сайта без перезагрузки). */
    private var currentUrl: String? = null
    private lateinit var navProfileAvatar: ImageView
    private lateinit var navNotifBadge: TextView
    private lateinit var navCoinsValue: TextView
    // Отдельный WebView для оплаты: основная страница остаётся загруженной и не теряет состояние.
    private var paymentWebView: WebView? = null
    private var paymentContainer: FrameLayout? = null
    private var paymentProgress: ProgressBar? = null

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoPath: String? = null
    private var pendingOpenPostCreator = false

    /** Вернулись из нативного чата — список переписок на странице нужно обновить. */
    private var reloadChatsOnResume = false

    companion object {
        private const val TAG = "FortPortClient"
        private const val REQUEST_CAMERA_PERMISSION = 5174
        private val SITE_HOST = "fortport.ru"
        private const val SITE_ORIGIN = "https://fortport.ru"

        /** Страница авторизации сайта. ПРОВЕРЬТЕ путь: если у сайта другой — поменяйте здесь. */
        private const val LOGIN_PATH = "/login"

        /** Страницы, которые можно открывать без входа (не перенаправляем с них на логин). */
        private val PUBLIC_PATH_PREFIXES = listOf(
            LOGIN_PATH, "/register", "/signup", "/about", "/privacy", "/terms", "/support", "/reset-password"
        )
    }

    /** null — ещё не знаем, true/false — по ответу сервера. */
    @Volatile private var isLoggedIn: Boolean? = null
    private var authRecheckPending = false
    @Volatile private var authConfirmationInFlight = false
    @Volatile private var authStateVersion = 0
    private val pendingAuthInvalidCallbacks = mutableListOf<() -> Unit>()
    /** Автоматически отправляем на логин только один раз за запуск, чтобы не зациклиться. */
    private var autoLoginRedirectDone = false

    private val fileChooserLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            handleFileChooserResult(result.resultCode, result.data)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)
        offlineView = findViewById(R.id.offlineView)
        offlineImage = findViewById(R.id.offlineImage)
        loadOfflineImage()
        bottomNavBar = findViewById(R.id.bottomNavBar)
        topNavBar = findViewById(R.id.topNavBar)
        sectionHeader = findViewById(R.id.sectionHeader)
        sectionHeaderIcon = findViewById(R.id.sectionHeaderIcon)
        sectionHeaderTitle = findViewById(R.id.sectionHeaderTitle)
        navHomeCenter = findViewById(R.id.navHomeCenter)
        nativeChatsPanel = findViewById(R.id.nativeChatsPanel)
        nativeFriendsPanel = findViewById(R.id.nativeFriendsPanel)
        nativeCommunitiesPanel = findViewById(R.id.nativeCommunitiesPanel)
        nativeMusicPanel = findViewById(R.id.nativeMusicPanel)
        nativeFeedPanel = findViewById(R.id.nativeFeedPanel)
        nativePostPanel = findViewById(R.id.nativePostPanel)
        nativeProfilePanel = findViewById(R.id.nativeProfilePanel)
        nativePortPanel = findViewById(R.id.nativePortPanel)
        nativeNotifsPanel = findViewById(R.id.nativeNotifsPanel)
        nativeSettingsPanel = findViewById(R.id.nativeSettingsPanel)
        settingsTopBar = findViewById(R.id.settingsTopBar)
        notifBottomBar = findViewById(R.id.notifBottomBar)
        postTopBar = findViewById(R.id.postTopBar)
        sectionHeaderAction = findViewById(R.id.sectionHeaderAction)
        // Основные верхняя (аватар, CD, уведомления) и нижняя (музыка, порты, пост/домой, друзья, переписки)
        // панели рисуются картинками из assets/ui (*_royal_panel-invert.png); нет файла — прежний цвет.
        // Шапки разделов и остальные панели не трогаем, как и шаблоны постов (UiUtil.royal).
        listOf(topNavBar, bottomNavBar).forEach { bar ->
            UiUtil.barSkin(this)?.let { bar.background = it }
        }
        siteApi = SiteApi(this)
        // Идентификатор устройства принадлежит нативному приложению, а не WebView.
        // Он должен оставаться одним и тем же для /api/login, подтверждения кода и bootstrap.
        siteApi.setSession("", getOrCreateNativeDeviceId(), webView.settings.userAgentString)
        val defaultBg = loadAssetIcon("styles/bg.webp")
        siteApi.attachBackground(findViewById(R.id.nativeChatsBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeFriendsBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeCommunitiesBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeMusicBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeFeedBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativePostBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeProfileBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativePortBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeNotifsBg), defaultBg)
        siteApi.attachBackground(findViewById(R.id.nativeSettingsBg), defaultBg)
        val openChat: (String) -> Unit = { json ->
            startActivity(Intent(this, ChatActivity::class.java).putExtra(ChatActivity.EXTRA_PAYLOAD, json))
        }
        val authLost: () -> Unit = {
            // Ошибка одного нативного API-запроса не доказывает, что сессия истекла.
            // Сначала подтверждаем состояние через /api/session/bootstrap.
            confirmSessionBeforeLogout {
                hideNativeSection()
                redirectToLoginIfNeeded()
            }
        }
        chatsController = ChatsListController(
            activity = this,
            api = siteApi,
            swipe = findViewById(R.id.chatsSwipe),
            recycler = findViewById(R.id.chatsRecycler),
            emptyView = findViewById(R.id.chatsEmpty),
            onOpenChat = openChat,
            onAuthLost = authLost
        )
        friendsController = FriendsListController(
            activity = this,
            api = siteApi,
            swipe = findViewById(R.id.friendsSwipe),
            recycler = findViewById(R.id.friendsRecycler),
            searchInput = findViewById(R.id.friendsSearch),
            onOpenChat = openChat,
            onOpenProfile = { id -> openNativeProfile(id) },
            onAuthLost = authLost
        )
        communitiesController = CommunitiesListController(
            activity = this,
            api = siteApi,
            swipe = findViewById(R.id.communitiesSwipe),
            recycler = findViewById(R.id.communitiesRecycler),
            searchInput = findViewById(R.id.communitiesSearch),
            onOpenCommunity = { id ->
                openNativeCommunity(id)
            },
            onCreateCommunity = {
                returnSection = nativeSection
                hideNativeSection()
                openWebPage("$SITE_ORIGIN/new_community")
            },
            onAuthLost = authLost
        )
        musicController = MusicController(
            activity = this,
            api = siteApi,
            swipe = findViewById(R.id.musicSwipe),
            recycler = findViewById(R.id.musicRecycler),
            emptyView = findViewById(R.id.musicEmpty),
            bg = findViewById(R.id.nativeMusicBg),
            disc = findViewById(R.id.musicDisc),
            titleView = findViewById(R.id.musicTitle),
            artistView = findViewById(R.id.musicArtist),
            timeCurrent = findViewById(R.id.musicTimeCurrent),
            timeTotal = findViewById(R.id.musicTimeTotal),
            seek = findViewById(R.id.musicSeek),
            btnShuffle = findViewById(R.id.musicShuffle),
            btnPrev = findViewById(R.id.musicPrev),
            btnPlay = findViewById(R.id.musicPlay),
            btnNext = findViewById(R.id.musicNext),
            btnRepeat = findViewById(R.id.musicRepeat),
            onLibraryChanged = { if (nativeSection == NativeSection.MUSIC) applyTopChrome(barsShouldShow()) },
            onAuthLost = authLost
        )
        feedController = FeedController(
            activity = this,
            api = siteApi,
            swipe = findViewById(R.id.feedSwipe),
            recycler = findViewById(R.id.feedRecycler),
            onOpenPost = { post -> openNativePost(post.id, post) },
            onOpenProfile = { id -> openNativeProfile(id) },
            onOpenCommunity = { id ->
                openNativeCommunity(id)
            },
            onBalanceChanged = { refreshCdCoinsBalance() },
            onAuthLost = authLost
        )
        postController = PostPageController(
            activity = this,
            api = siteApi,
            repo = feedController.repo,
            swipe = findViewById(R.id.postSwipe),
            recycler = findViewById(R.id.postRecycler),
            onOpenProfile = { id -> openNativeProfile(id) },
            onOpenCommunity = { id ->
                openNativeCommunity(id)
            },
            onBalanceChanged = { refreshCdCoinsBalance() },
            onAuthLost = authLost,
            pickFile = { done -> commentPickCb = done; commentPicker.launch("*/*") },
            onClose = { feedController.dropPost(pendingPostId); profileController.dropPost(pendingPostId); portController.dropPost(pendingPostId); onBackPressed() }
        )
        notifsController = NotificationsController(
            activity = this,
            api = siteApi,
            swipe = findViewById(R.id.notifsSwipe),
            recycler = findViewById(R.id.notifsRecycler),
            onOpenPost = { postId, commentId ->
                openNativePost(postId, null)
                if (commentId != 0L) postController.focusComment(commentId)
            },
            onOpenProfile = { id -> openNativeProfile(id) },
            onCount = { n ->
                if (n <= 0) navNotifBadge.visibility = View.GONE
                else { navNotifBadge.text = if (n > 99) "99+" else n.toString(); navNotifBadge.visibility = View.VISIBLE }
            },
            onAuthLost = authLost
        )
        loginController = LoginController(
            activity = this,
            api = siteApi,
            root = findViewById(R.id.rootLayout),
            onLoggedIn = { user -> onNativeLoginSuccess(user) },
            onOpenWeb = { path ->
                loginController.hide()
                openWebPage(SITE_ORIGIN + path)
            }
        )
        findViewById<View>(R.id.notifReadAll).setOnClickListener { notifsController.markAll() }
        findViewById<View>(R.id.notifRefresh).setOnClickListener { notifsController.refresh() }
        findViewById<View>(R.id.notifHome).setOnClickListener {
            returnSection = null
            navFrames.clear()
            showNativeSection(NativeSection.FEED)
        }
        portController = PortController(
            activity = this,
            api = siteApi,
            repo = feedController.repo,
            swipe = findViewById(R.id.portSwipe),
            recycler = findViewById(R.id.portRecycler),
            bg = findViewById(R.id.nativePortBg),
            onOpenPost = { post -> openNativePost(post.id, post) },
            onOpenProfile = { id -> openNativeProfile(id) },
            onOpenWeb = { path ->
                returnSection = NativeSection.PORT
                returnPortId = pendingCommunityId
                hideNativeSection()
                openWebPage("$SITE_ORIGIN$path")
            },
            onInfoLoaded = { if (nativeSection == NativeSection.PORT) updateAddPostButton(currentUrl) },
            onBalanceChanged = { refreshCdCoinsBalance() },
            onAuthLost = authLost
        )
        profileController = ProfileController(
            activity = this,
            api = siteApi,
            repo = feedController.repo,
            swipe = findViewById(R.id.profileSwipe),
            recycler = findViewById(R.id.profileRecycler),
            bg = findViewById(R.id.nativeProfileBg),
            onOpenPost = { post -> openNativePost(post.id, post) },
            onOpenProfile = { id -> openNativeProfile(id) },
            onOpenCommunity = { id ->
                openNativeCommunity(id)
            },
            onOpenMusic = { id ->
                pushNavFrame()
                pendingMusicUserId = id.toString()
                showNativeSection(NativeSection.MUSIC)
            },
            onOpenFriends = { id ->
                pushNavFrame()
                pendingFriendsUserId = id.toString()
                showNativeSection(NativeSection.FRIENDS)
            },
            onOpenPorts = { id ->
                pushNavFrame()
                pendingCommunitiesUserId = id.toString()
                showNativeSection(NativeSection.COMMUNITIES)
            },
            onOpenWeb = { path ->
                returnSection = NativeSection.PROFILE
                returnProfileId = pendingProfileId
                hideNativeSection()
                openWebPage("$SITE_ORIGIN$path")
            },
            onOpenChat = openChat,
            onBalanceChanged = { refreshCdCoinsBalance() },
            onAuthLost = authLost
        )
        settingsController = SettingsController(
            activity = this,
            api = siteApi,
            host = findViewById(R.id.settingsHost),
            pickImage = { done -> commentPickCb = done; commentPicker.launch("image/*") },
            onAuthLost = authLost
        )
        findViewById<View>(R.id.postBackButton).setOnClickListener { onBackPressed() }
        findViewById<View>(R.id.settingsBackButton).setOnClickListener { onBackPressed() }
        try {
            assets.open("ui/icons/setting_icon.png").use { findViewById<ImageView>(R.id.settingsTopIcon).setImageBitmap(BitmapFactory.decodeStream(it)) }
        } catch (e: Exception) { /* иконку положат в assets/ui/icons позже */ }
        sectionHeaderAction.setOnClickListener { musicController.pickFromDevice() }
        navProfileAvatar = findViewById(R.id.navProfileAvatar)
        navNotifBadge = findViewById(R.id.navNotifBadge)
        navCoinsValue = findViewById(R.id.navCoinsValue)

        findViewById<Button>(R.id.retryButton).setOnClickListener {
            loadSite()
        }

        setupWebView()
        setupSwipeRefresh()
        setupBottomNav()
        setupTopNav()

        // Основной сценарий полностью нативный: не загружаем /login и ленту в WebView.
        // WebView включается только для дополнительных страниц без нативной реализации.
        siteApi.setSession("", getOrCreateNativeDeviceId(), webView.settings.userAgentString)
        swipeRefresh.visibility = View.GONE
        webView.visibility = View.GONE
        loginController.showChecking() // форма входа появится только если сессии нет
        if (!isNetworkAvailable()) showOffline() else offlineView.visibility = View.GONE
        if (savedInstanceState != null) {
            // Не восстанавливаем WebView как главный экран: он может вернуть веб-форму входа.
            webView.clearHistory()
        }
        restoreNativeSession()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        // Запрещаем pinch-to-zoom и системные элементы масштабирования в WebView.
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        // Заставляем WebView полноценно использовать мобильный viewport страницы
        // (без этого некоторые сайты рендерят слишком широкий "десктопный" layout).
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL

        // WebView добавляет в User-Agent метку "; wv", по которой многие сайты
        // определяют его как "не мобильный браузер" и отдают чуть другую вёрстку
        // (например, немасштабированные модальные окна). Убираем эту метку и
        // приводим строку к виду обычного мобильного Chrome — это решает
        // большинство подобных проблем с адаптивностью без изменений на сайте.
        settings.userAgentString = buildMobileUserAgent(settings.userAgentString)

        // Разрешаем несколько окон (некоторые ссылки открываются через window.open)
        settings.setSupportMultipleWindows(false)
        settings.javaScriptCanOpenWindowsAutomatically = true

        // Куки, чтобы сессия входа сохранялась между запусками
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        // Мост со страницы в нативный код — используется, чтобы прятать/
        // показывать нижнюю панель навигации при скролле ленты.
        webView.addJavascriptInterface(ScrollBridge(), "AndroidNav")
        // Мост для нативного просмотра фото (см. injectPhotoViewerHook)
        webView.addJavascriptInterface(PhotoBridge(), "AndroidPhoto")

        // Тёмная тема: подстраиваем содержимое страницы под системную тему устройства
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            val isNightMode = (resources.configuration.uiMode and
                    android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(settings, isNightMode)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url
                Log.d(TAG, "nav ${request.method} $url redirect=${request.isRedirect} gesture=${request.hasGesture()}")
                // Ссылки на списки переписок и друзей открываем нативными экранами, а не веб-страницами.
                if (isLoggedIn != false) {
                    val section = nativeSectionFor(url)
                    if (section != null) {
                        runOnUiThread { showNativeSection(section) }
                        return true
                    }
                }
                return if (url.host?.endsWith(SITE_HOST) == true) {
                    false // открываем внутри приложения
                } else {
                    // Внешние ссылки (например, соцсети, платёжные системы) — во внешнем браузере
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, url))
                    } catch (e: Exception) {
                        Log.w(TAG, "Не удалось открыть внешнюю ссылку: $url", e)
                    }
                    true
                }
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url

                // 1) Файлы, зашитые прямо в APK — доступны даже без единого запроса в сеть.
                BundledAssets.tryLoad(this@MainActivity, url)?.let { return it }

                // 2) Обычный статический ассет сайта — кэшируем на диск при первой загрузке.
                return if (AssetCache.isCacheable(url, SITE_HOST)) {
                    AssetCache.load(cacheDir, url) ?: super.shouldInterceptRequest(view, request)
                } else {
                    super.shouldInterceptRequest(view, request)
                }
            }

            // Срабатывает и при переходах внутри страницы (JS-роутинг сайта без
            // полной перезагрузки), поэтому состояние кнопки обновляем здесь.
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                if (url != null && isLoggedIn != false) {
                    val uri = Uri.parse(url)
                    // JS-переход сайта на список переписок/друзей (или закрытие веб-диалога) — показываем нативный.
                    if (skipNativeNavOnce) skipNativeNavOnce = false
                    else nativeSectionFor(uri)?.let { showNativeSection(it) }
                }
                updateAddPostButton(url)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
                lastLoadFailed = false
                if (pathOf(url) != LOGIN_PATH && isLoggedIn == true) loginController.hide()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
                syncLoginOverlay(view, url)
                // Лента открылась поверх только что загруженной главной: сессия сайта (userId/deviceId) теперь точно доступна.
                if (nativeSection == NativeSection.FEED || nativeSection == NativeSection.PROFILE || nativeSection == NativeSection.PORT) startNativeLoading()

                // lastLoadFailed может быть true даже если сеть на устройстве есть —
                // например, когда сам сервер сейчас не отвечает (не наш случай
                // "нет интернета", а именно "сервер недоступен"). В этом случае
                // WebView всё равно вызывает onPageFinished следом за
                // onReceivedError/onReceivedHttpError — не даём ему тут же скрыть
                // плашку и показать содержимое неудачной загрузки.
                if (!lastLoadFailed) {
                    offlineView.visibility = View.GONE
                    swipeRefresh.visibility = View.VISIBLE
                    injectMobileLayoutSafetyNet(view)
                    injectNavCleanup(view)
                    injectScrollTracking(view)
                    injectPhotoViewerHook(view)
                    injectChatWatcher(view)
                    updateBarsVisibility()
                    loadProfileAvatar()
                    refreshCdCoinsBalance()

                    if (pendingOpenPostCreator) {
                        pendingOpenPostCreator = false
                        runOpenPostCreatorJs()
                    }
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    lastLoadFailed = true
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    showOffline()
                }
            }

            // Срабатывает, когда сервер отвечает, но кодом ошибки (502/503 и т.п.) —
            // браузерная/прокси страница ошибки иначе отрисовалась бы прямо в WebView.
            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                Log.w(
                    TAG,
                    "HTTP ${errorResponse.statusCode} ${request.method} ${request.url} " +
                        "mainFrame=${request.isForMainFrame}"
                )
                // Плашку "нет подключения" показываем только при сбоях сервера (5xx).
                // 4xx (404, 403 и т.п.) — это нормальный ответ сайта: пусть WebView
                // отрисует его страницу, а не прячет причину за нашей заглушкой.
                if (request.isForMainFrame && errorResponse.statusCode >= 500) {
                    lastLoadFailed = true
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    showOffline()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
            }

            // Пока у <video> нет первого кадра (например, при смене анимации
            // маскота через video.src), Android WebView рисует стандартную
            // серую плашку с кнопкой play. Подменяем её прозрачным пикселем.
            private val transparentPoster: Bitmap by lazy {
                Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            }

            override fun getDefaultVideoPoster(): Bitmap = transparentPoster

            // Пробрасываем console.log/warn/error со страницы в Logcat (тег
            // JsConsole) — без этого ошибки JS на странице (например, при
            // отправке поста) происходят молча и незаметно.
            override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                Log.d(
                    "JsConsole",
                    "[${message.messageLevel()}] ${message.message()} " +
                        "(${message.sourceId()}:${message.lineNumber()})"
                )
                return true
            }

            // Без этого alert()/confirm() из JS сайта не показываются вообще —
            // стандартный WebChromeClient их просто игнорирует. Именно на них
            // завязаны сообщения об ошибках при отправке поста ("Ошибка: ...",
            // "Ошибка сервера" в post.js).
            override fun onJsAlert(
                view: WebView,
                url: String?,
                message: String?,
                result: JsResult
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnDismissListener { result.confirm() }
                    .setCancelable(false)
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView,
                url: String?,
                message: String?,
                result: JsResult
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            // Обработка <input type="file"> — выбор фото из галереи или съёмка с камеры
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback

                val chooserIntent = createFileChooserIntent(params)
                try {
                    fileChooserLauncher.launch(chooserIntent)
                } catch (e: Exception) {
                    Log.e(TAG, "Не удалось запустить выбор файла", e)
                    filePathCallback = null
                    return false
                }
                return true
            }
        }
    }

    private fun createFileChooserIntent(params: WebChromeClient.FileChooserParams): Intent {
        var takePictureIntent: Intent? = null
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            val photoFile = createImageFile()
            if (photoFile != null) {
                cameraPhotoPath = photoFile.absolutePath
                val photoUri = FileProvider.getUriForFile(
                    this, "$packageName.fileprovider", photoFile
                )
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            } else {
                takePictureIntent = null
            }
        } else {
            requestCameraPermission()
        }

        val contentSelectionIntent = Intent(Intent.ACTION_GET_CONTENT)
        contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE)
        contentSelectionIntent.type = "*/*"
        val mimeTypes = params.acceptTypes?.filter { it.isNotBlank() }
        if (!mimeTypes.isNullOrEmpty()) {
            contentSelectionIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
        }

        val intentArray = if (takePictureIntent != null) arrayOf(takePictureIntent) else arrayOf()

        return Intent(Intent.ACTION_CHOOSER).apply {
            putExtra(Intent.EXTRA_INTENT, contentSelectionIntent)
            putExtra(Intent.EXTRA_TITLE, "Выберите файл")
            putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray)
        }
    }

    private fun requestCameraPermission() {
        androidx.core.app.ActivityCompat.requestPermissions(
            this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION
        )
    }

    private fun createImageFile(): File? {
        return try {
            val storageDir = File(cacheDir, "images").apply { mkdirs() }
            File.createTempFile("PHOTO_", ".jpg", storageDir)
        } catch (e: Exception) {
            Log.e(TAG, "Не удалось создать файл для фото", e)
            null
        }
    }

    private fun handleFileChooserResult(resultCode: Int, data: Intent?) {
        if (filePathCallback == null) return

        var results: Array<Uri>? = null
        if (resultCode == Activity.RESULT_OK) {
            if (data == null || data.data == null) {
                // Файл мог быть создан камерой
                if (cameraPhotoPath != null) {
                    results = arrayOf(Uri.fromFile(File(cameraPhotoPath!!)))
                }
            } else {
                val clipData = data.clipData
                if (clipData != null) {
                    results = Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                } else {
                    results = arrayOf(data.data!!)
                }
            }
        }
        filePathCallback?.onReceiveValue(results)
        filePathCallback = null
    }

    private fun setupSwipeRefresh() {
        swipeRefresh.setColorSchemeResources(R.color.fp_accent)
        swipeRefresh.setOnRefreshListener {
            if (isNetworkAvailable()) {
                webView.reload()
            } else {
                swipeRefresh.isRefreshing = false
                showOffline()
            }
        }
    }

    /**
     * Нативная нижняя панель: Музыка / Порты (сообщества) / Добавить пост /
     * Друзья / Переписки. Иконки — те же .webp-файлы, что уже зашиты в
     * app/src/main/assets/ui/icons для WebView; тут они просто декодируются
     * ещё раз как Bitmap для обычных ImageButton.
     */
    private fun setupBottomNav() {
        findViewById<ImageButton>(R.id.navMusic).apply {
            setImageBitmap(loadAssetIcon("ui/icons/audios_aero.webp"))
            setOnClickListener { returnSection = null; navFrames.clear(); pendingMusicUserId = null; showNativeSection(NativeSection.MUSIC) }
        }
        findViewById<ImageButton>(R.id.navCommunities).apply {
            setImageBitmap(loadAssetIcon("ui/icons/communities_aero.webp"))
            setOnClickListener { returnSection = null; navFrames.clear(); pendingCommunitiesUserId = null; showNativeSection(NativeSection.COMMUNITIES) }
        }
        findViewById<ImageButton>(R.id.navAddPost).apply {
            setImageBitmap(loadAssetIcon("ui/icons/new_post.webp"))
            setOnClickListener { openPostCreator() }
        }
        navHomeCenter.setOnClickListener { returnSection = null; navFrames.clear(); showNativeSection(NativeSection.FEED) }
        findViewById<ImageButton>(R.id.navFriends).apply {
            setImageBitmap(loadAssetIcon("ui/icons/friends_aero.webp"))
            setOnClickListener { returnSection = null; navFrames.clear(); pendingFriendsUserId = null; showNativeSection(NativeSection.FRIENDS) }
        }
        findViewById<ImageButton>(R.id.navChats).apply {
            setImageBitmap(loadAssetIcon("ui/icons/chats_aero.webp"))
            setOnClickListener { returnSection = null; navFrames.clear(); showNativeSection(NativeSection.CHATS) }
        }
    }

    private fun loadAssetIcon(path: String) = try {
        assets.open(path).use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        Log.w(TAG, "Не удалось загрузить иконку из assets: $path", e)
        null
    }

    /**
     * Нативная верхняя панель — замена #main-top-bar сайта (createUtilityBar()/
     * updateAuthButtons() в auth.js), которую прячем через injectNavCleanup().
     */
    private fun setupTopNav() {
        findViewById<ImageButton>(R.id.navHome).setOnClickListener {
            returnSection = null
            navFrames.clear()
            showNativeSection(NativeSection.FEED)
        }
        findViewById<ImageView>(R.id.navCoinsIcon).setImageBitmap(loadAssetIcon("ui/icons/cd_coin.png"))
        findViewById<LinearLayout>(R.id.navCoins).setOnClickListener {
            showCdCoinsPurchaseDialog()
        }
        findViewById<ImageButton>(R.id.navNotifs).apply {
            setImageBitmap(loadAssetIcon("ui/icons/bell_aero.webp"))
            setOnClickListener { openNotifications() }
        }
        findViewById<LinearLayout>(R.id.navProfile).setOnClickListener { anchor ->
            if (isLoggedIn == false && !isPublicPath(webView.url)) {
                openLoginPage()
            } else {
                // На странице входа состояние могло смениться без перезагрузки — перепроверяем.
                if (isLoggedIn == false) refreshCdCoinsBalance()
                showProfileMenu(anchor)
            }
        }
    }

    private fun isPublicPath(url: String?): Boolean {
        val path = try { Uri.parse(url).path.orEmpty().trimEnd('/') } catch (e: Exception) { "" }
        return PUBLIC_PATH_PREFIXES.any { path == it || path.startsWith("$it/") }
    }

    /**
     * Нативные верхняя и нижняя панели нужны только авторизованному пользователю:
     * без сессии и на страницах входа/регистрации они скрыты.
     */
    private fun updateBarsVisibility() {
        if (paymentWebView != null) return // в платёжном режиме панели уже скрыты
        val show = barsShouldShow()
        if (!show) hideNativeSection()
        bottomNavBar.visibility = if (show) View.VISIBLE else View.GONE
        applyTopChrome(show)
        if (show) showBottomNav()
    }

    private fun barsShouldShow(): Boolean {
        val path = pathOf(currentUrl ?: webView.url)
        val authPage = isPublicPath(currentUrl ?: webView.url) &&
            PUBLIC_PATH_PREFIXES.take(3).any { path.startsWith(it) }
        return isLoggedIn != false && !authPage
    }

    private fun pathOf(url: String?): String =
        try { Uri.parse(url ?: "").path.orEmpty().trimEnd('/') } catch (e: Exception) { "" }

    /** Нативная «шапка раздела» (иконка + название) вместо полной верхней панели. */
    private class SectionChrome(val iconAsset: String, val titleRes: Int)

    private val chatsChrome = SectionChrome("ui/icons/chats_aero.webp", R.string.nav_chats)
    private val friendsChrome = SectionChrome("ui/icons/friends_aero.webp", R.string.nav_friends)
    private val communitiesChrome = SectionChrome("ui/icons/communities_aero.webp", R.string.nav_communities)
    private val musicChrome = SectionChrome("ui/icons/audios_aero.webp", R.string.nav_music)
    private val notifsChrome = SectionChrome("ui/icons/bell_aero.webp", R.string.nav_notifs)

    private fun activeSectionChrome(): SectionChrome? = when (nativeSection) {
        NativeSection.CHATS -> chatsChrome
        NativeSection.FRIENDS -> friendsChrome
        NativeSection.COMMUNITIES -> communitiesChrome
        NativeSection.MUSIC -> musicChrome
        NativeSection.NOTIFS -> notifsChrome
        NativeSection.FEED, NativeSection.POST, NativeSection.PROFILE, NativeSection.PORT, NativeSection.SETTINGS, null -> null // у ленты обычные панели, у поста — стрелка назад
    }

    /** Показывает либо обычную верхнюю панель, либо шапку раздела, либо ничего. */
    private fun applyTopChrome(barsVisible: Boolean) {
        val section = if (barsVisible) activeSectionChrome() else null
        val inPost = barsVisible && nativeSection == NativeSection.POST
        val inSettings = barsVisible && nativeSection == NativeSection.SETTINGS
        if (section != null) {
            sectionHeaderIcon.setImageBitmap(loadAssetIcon(section.iconAsset))
            sectionHeaderTitle.setText(section.titleRes)
            // Чужая библиотека: «Музыка: имя».
            if (nativeSection == NativeSection.MUSIC && !musicController.isOwnLibrary && musicController.viewedName.isNotBlank()) {
                sectionHeaderTitle.text = getString(section.titleRes) + ": " + musicController.viewedName
            }
        }
        sectionHeader.visibility = if (section != null) View.VISIBLE else View.GONE
        topNavBar.visibility = if (barsVisible && section == null && !inPost && !inSettings) View.VISIBLE else View.GONE
        settingsTopBar.visibility = if (inSettings) View.VISIBLE else View.GONE
        postTopBar.visibility = if (inPost) View.VISIBLE else View.GONE
        // Открытый пост: нижней панели нет, она возвращается после выхода из поста.
        val inNotifs = barsVisible && nativeSection == NativeSection.NOTIFS
        notifBottomBar.visibility = if (inNotifs) View.VISIBLE else View.GONE
        if (paymentWebView == null && barsVisible) bottomNavBar.visibility = if (inPost || inNotifs || inSettings) View.GONE else View.VISIBLE
        // Загрузка с устройства — только в своей библиотеке.
        sectionHeaderAction.visibility =
            if (section != null && nativeSection == NativeSection.MUSIC && musicController.isOwnLibrary) View.VISIBLE else View.GONE
    }

    /**
     * Перехватывает открытие диалога на странице /chats и показывает вместо него
     * нативный экран (ChatActivity). Сайт при открытии диалога ставит body-класс
     * `mobile-chat-open` и пишет `?chatId=…` в адрес (chats.js, openChat()), поэтому
     * достаточно следить за классом: берём chatId, имя/аватар собеседника из DOM,
     * передаём в приложение и закрываем веб-диалог его же функцией chatFeedmainClose()
     * (она останавливает long-poll сайта, чтобы он не «воровал» события у нативного экрана).
     */
    private fun injectChatWatcher(view: WebView) {
        val js = """
            (function() {
                if (window.__fpChatHooked) { if (window.__fpChatCheck) window.__fpChatCheck(); return; }
                window.__fpChatHooked = true;

                if (!document.getElementById('fortport-client-chat-style')) {
                    var st = document.createElement('style');
                    st.id = 'fortport-client-chat-style';
                    // Веб-диалог не мигает на экране: его место занимает нативный.
                    st.textContent = 'body.mobile-chat-open .chat-feedmain, body.mobile-chat-open #chat-feedmain { visibility: hidden !important; }';
                    document.head.appendChild(st);
                }

                // Веб-версия чата больше не должна слушать /api/chats/{id}/wait: этот long-poll
                // делит события с нативным экраном, и страница «забирала» бы часть сообщений.
                if (!window.__fpWaitBlocked) {
                    window.__fpWaitBlocked = true;
                    var origFetch = window.fetch;
                    window.fetch = function(input) {
                        try {
                            var u = (typeof input === 'string') ? input : ((input && input.url) || '');
                            if (/\/api\/chats\/[^\/]+\/wait/.test(u)) return new Promise(function() {});
                        } catch (e) {}
                        return origFetch.apply(this, arguments);
                    };
                }

                var launched = false;
                function ls(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }

                function check() {
                    var open = document.body && document.body.classList.contains('mobile-chat-open');
                    if (!open) { launched = false; return; }
                    if (launched) return;
                    var chatId = new URLSearchParams(location.search).get('chatId');
                    if (!chatId || !window.AndroidNav || !window.AndroidNav.openNativeChat) return;
                    launched = true;
                    var nameEl = document.getElementById('chat-partner-name');
                    var avEl = document.getElementById('chat-partner-avatar');
                    var stEl = document.getElementById('chat-partner-status');
                    var av = avEl ? (avEl.getAttribute('src') || '') : '';
                    if (av.indexOf('default-avatar') >= 0) av = '';
                    window.AndroidNav.openNativeChat(JSON.stringify({
                        chatId: chatId,
                        name: nameEl ? nameEl.textContent : '',
                        avatar: av,
                        status: stEl ? stEl.textContent : '',
                        myId: ls('userId'),
                        deviceId: ls('deviceId'),
                        ua: navigator.userAgent
                    }));
                    // Закрываем веб-диалог без записи в историю и убираем chatId из адреса.
                    try {
                        if (typeof window.chatFeedmainClose === 'function') window.chatFeedmainClose({ skipHistory: true });
                        var u = new URL(location.href);
                        u.searchParams.delete('chatId'); u.searchParams.delete('id');
                        history.replaceState({}, '', u);
                    } catch (e) {
                        var back = document.getElementById('chat-mobile-back');
                        if (back) back.click();
                    }
                    // openChat() сайта ещё доработает свои await'ы и может заново запустить опрос —
                    // повторно закрываем диалог, чтобы остановить его (см. блокировку fetch выше).
                    [800, 2500].forEach(function(ms) {
                        setTimeout(function() {
                            try { if (typeof window.chatFeedmainClose === 'function') window.chatFeedmainClose({ skipHistory: true }); } catch (e) {}
                        }, ms);
                    });
                }

                window.__fpChatCheck = check;
                new MutationObserver(check).observe(document.body, { attributes: true, attributeFilter: ['class'] });
                window.addEventListener('popstate', function() { setTimeout(check, 0); });
                check();
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun showNativeSection(section: NativeSection) {
        if (isLoggedIn == false) return
        if (section == NativeSection.MUSIC) {
            val changed = musicController.setViewedUser(pendingMusicUserId)
            if (changed && nativeSection == NativeSection.MUSIC) {
                // Уже на вкладке «Музыка», но открыли библиотеку другого человека (или вернулись к своей).
                updateAddPostButton(currentUrl)
                startNativeLoading()
                return
            }
        }
        if (section != NativeSection.POST && section != NativeSection.PROFILE && section != NativeSection.MUSIC &&
            section != NativeSection.FRIENDS && section != NativeSection.COMMUNITIES && section != NativeSection.PORT && section != NativeSection.NOTIFS && section != NativeSection.SETTINGS) navFrames.clear()
        if (section == NativeSection.FRIENDS) {
            val changed = friendsController.setViewedUser(pendingFriendsUserId)
            applyListViewMode()
            if (changed && nativeSection == NativeSection.FRIENDS) { startNativeLoading(); return }
        }
        if (section == NativeSection.COMMUNITIES) {
            val changed = communitiesController.setViewedUser(pendingCommunitiesUserId)
            applyListViewMode()
            if (changed && nativeSection == NativeSection.COMMUNITIES) { startNativeLoading(); return }
        }
        if (section == NativeSection.POST) {
            postController.setPost(pendingPostId, pendingPost)
            if (nativeSection == NativeSection.POST) { postController.stop(); startNativeLoading(); return }
        }
        if (section == NativeSection.PORT) {
            portController.setCommunity(pendingCommunityId)
            if (nativeSection == NativeSection.PORT) { portController.stop(); startNativeLoading(); return }
        }
        if (section == NativeSection.PROFILE) {
            profileController.setUser(pendingProfileId)
            if (nativeSection == NativeSection.PROFILE) { profileController.stop(); startNativeLoading(); return }
        }
        if (nativeSection == section) return
        // Переключение между нативными вкладками: прежнюю останавливаем и прячем.
        stopNativeControllers()
        resetNativeSearch(nativeSection)
        nativeSection = section
        nativeChatsPanel.visibility = if (section == NativeSection.CHATS) View.VISIBLE else View.GONE
        nativeFriendsPanel.visibility = if (section == NativeSection.FRIENDS) View.VISIBLE else View.GONE
        nativeCommunitiesPanel.visibility = if (section == NativeSection.COMMUNITIES) View.VISIBLE else View.GONE
        nativeMusicPanel.visibility = if (section == NativeSection.MUSIC) View.VISIBLE else View.GONE
        nativeFeedPanel.visibility = if (section == NativeSection.FEED) View.VISIBLE else View.GONE
        nativePostPanel.visibility = if (section == NativeSection.POST) View.VISIBLE else View.GONE
        nativeProfilePanel.visibility = if (section == NativeSection.PROFILE) View.VISIBLE else View.GONE
        nativePortPanel.visibility = if (section == NativeSection.PORT) View.VISIBLE else View.GONE
        nativeNotifsPanel.visibility = if (section == NativeSection.NOTIFS) View.VISIBLE else View.GONE
        nativeSettingsPanel.visibility = if (section == NativeSection.SETTINGS) View.VISIBLE else View.GONE
        updateAddPostButton(currentUrl)
        showBottomNav()
        startNativeLoading()
    }

    /** Нативная страница поста (концепция 3). [post] — уже загруженная карточка из ленты, чтобы показать её сразу. */
    private fun openNativePost(id: Long, post: Post?) {
        if (nativeSection != NativeSection.POST) postParent = nativeSection
        pendingPostId = id
        pendingPost = post
        showNativeSection(NativeSection.POST)
    }

    /** В списках чужих друзей/портов строка поиска скрыта, список начинается выше. */
    private fun applyListViewMode() {
        fun adjust(search: View, recycler: View, viewing: Boolean) {
            (search.parent as? View)?.visibility = if (viewing) View.GONE else View.VISIBLE
            val top = (if (viewing) 78 else 136) * resources.displayMetrics.density
            recycler.setPadding(recycler.paddingLeft, top.toInt(), recycler.paddingRight, recycler.paddingBottom)
        }
        adjust(findViewById(R.id.friendsSearch), findViewById(R.id.friendsRecycler), friendsController.viewing)
        adjust(findViewById(R.id.communitiesSearch), findViewById(R.id.communitiesRecycler), communitiesController.viewing)
    }

    /** Запоминает текущий нативный экран, чтобы «Назад» из профиля/музыки вернул в него. */
    private fun pushNavFrame() {
        val cur = nativeSection ?: return
        navFrames.add(NavFrame(cur, pendingPostId, postParent, pendingProfileId, pendingCommunityId))
    }

    /** Нативные уведомления: экран под ними (лента, профиль, порт, пост) остаётся как был. */
    private fun openNotifications() {
        if (nativeSection == NativeSection.NOTIFS) { notifsController.refresh(); return }
        if (nativeSection == null) navFrames.clear()
        pushNavFrame()
        showNativeSection(NativeSection.NOTIFS)
    }

    /** Нативная лента порта (концепция 5). */
    private fun openNativeCommunity(id: Long) {
        if (nativeSection == null) navFrames.clear()
        pushNavFrame()
        pendingCommunityId = id
        showNativeSection(NativeSection.PORT)
    }

    /** Выход из тестового режима: назад к форме входа (данные тестового аккаунта остаются на устройстве). */
    private fun leaveDemo() {
        siteApi.exitDemo()
        isLoggedIn = false
        returnSection = null
        navFrames.clear()
        hideNativeSection()
        swipeRefresh.visibility = View.GONE
        webView.visibility = View.GONE
        updateBarsVisibility()
        loginController.show()
    }

    /** Нативные настройки профиля (вкладки «Профиль», «Безопасность», «Кастомизация»). */
    private fun openNativeSettings() {
        if (nativeSection == NativeSection.SETTINGS) return
        if (nativeSection == null) navFrames.clear()
        pushNavFrame()
        showNativeSection(NativeSection.SETTINGS)
    }

    /** Нативный профиль пользователя (концепция 4). */
    private fun openNativeProfile(id: Long) {
        if (nativeSection == null) navFrames.clear()
        pushNavFrame()
        pendingProfileId = id
        showNativeSection(NativeSection.PROFILE)
    }

    /** Возврат на предыдущий нативный экран из стека. false — стек пуст. */
    private fun popNavFrame(): Boolean {
        if (navFrames.isEmpty()) return false
        val f = navFrames.removeAt(navFrames.size - 1)
        pendingProfileId = f.profileId
        pendingCommunityId = f.communityId
        if (f.section == NativeSection.POST) {
            pendingPostId = f.postId
            pendingPost = null
            postParent = f.postParent
        }
        showNativeSection(f.section)
        return true
    }

    private fun startNativeLoading() {
        if (isFinishing || isDestroyed) return
        val uid = siteApi.userId
        val did = siteApi.deviceId.ifBlank { getOrCreateNativeDeviceId() }
        val ua = webView.settings.userAgentString
        siteApi.setSession(uid, did, ua)
        when (nativeSection) {
            NativeSection.CHATS -> chatsController.start(uid, did, ua)
            NativeSection.FRIENDS -> friendsController.start(uid, did, ua)
            NativeSection.COMMUNITIES -> communitiesController.start(uid, did, ua)
            NativeSection.MUSIC -> musicController.start(uid, did, ua)
            NativeSection.FEED -> feedController.start(uid, did, ua)
            NativeSection.POST -> postController.start(uid, did, ua)
            NativeSection.PROFILE -> profileController.start(uid, did, ua)
            NativeSection.PORT -> portController.start(uid, did, ua)
            NativeSection.NOTIFS -> notifsController.start(uid, did, ua)
            NativeSection.SETTINGS -> settingsController.start(uid, did, ua)
            null -> {}
        }
    }

    private fun hideNativeSection() {
        if (nativeSection == null) return
        val was = nativeSection
        nativeSection = null
        nativeChatsPanel.visibility = View.GONE
        nativeFriendsPanel.visibility = View.GONE
        nativeCommunitiesPanel.visibility = View.GONE
        nativeMusicPanel.visibility = View.GONE
        nativeFeedPanel.visibility = View.GONE
        nativePostPanel.visibility = View.GONE
        nativeProfilePanel.visibility = View.GONE
        nativePortPanel.visibility = View.GONE
        nativeNotifsPanel.visibility = View.GONE
        nativeSettingsPanel.visibility = View.GONE
        stopNativeControllers()
        resetNativeSearch(was)
        updateAddPostButton(currentUrl)
    }

    private fun stopNativeControllers() {
        chatsController.stop()
        friendsController.stop()
        communitiesController.stop()
        musicController.stop()
        feedController.stop()
        postController.stop()
        profileController.stop()
        portController.stop()
        notifsController.stop()
        settingsController.stop()
    }

    /** Строка поиска очищается при уходе с вкладки (как при новой загрузке страницы на сайте). */
    private fun resetNativeSearch(section: NativeSection?) {
        when (section) {
            NativeSection.FRIENDS -> friendsController.reset()
            NativeSection.COMMUNITIES -> communitiesController.reset()
            else -> {}
        }
    }

    /** Уход с нативной вкладки на веб-страницу кнопками панели. */
    private fun leaveNative() {
        returnSection = null
        navFrames.clear()
        hideNativeSection()
    }

    /** Нативный экран для адреса: /chats и /friends без параметров (с chatId/id — веб, как раньше). */
    private fun nativeSectionFor(uri: Uri): NativeSection? {
        if (uri.host?.endsWith(SITE_HOST) != true) return null
        val path = uri.path.orEmpty().trimEnd('/')
        if (path == "/music") {
            // Своя библиотека (без id или с собственным id) — нативный плеер; чужая — веб-страница.
            val id = uri.getQueryParameter("id")
            if (id != null && !id.all { it.isDigit() }) return null
            pendingMusicUserId = id?.takeIf { it.isNotEmpty() } // совпадение с собственным id определяет сам экран
            return NativeSection.MUSIC
        }
        if (path == "/post") {
            // Ссылка на пост (из уведомления, чата, JS-роутинга сайта) — нативная страница поста.
            val id = uri.getQueryParameter("id")?.toLongOrNull() ?: return null
            pendingPostId = id
            pendingPost = null
            return NativeSection.POST
        }
        if (path == "/community") {
            // Страница порта (из уведомления, чата, JS-перехода сайта) — нативная лента порта.
            val id = uri.getQueryParameter("id")?.toLongOrNull() ?: return null
            pendingCommunityId = id
            return NativeSection.PORT
        }
        if (path == "/settings") return NativeSection.SETTINGS
        if (path == "/profile") {
            // Страница пользователя (из меню, уведомления, JS-перехода сайта) — нативная лента пользователя.
            val id = uri.getQueryParameter("id")
            if (id != null && !id.all { it.isDigit() }) return null
            pendingProfileId = id?.toLongOrNull() ?: 0L
            return NativeSection.PROFILE
        }
        if (uri.getQueryParameter("chatId") != null || uri.getQueryParameter("id") != null) return null
        // Главная (основная лента). Самую первую загрузку сайта не перехватываем: сначала страница
        // должна открыться, чтобы в WebView появилась сессия (userId/deviceId в localStorage).
        if (path.isEmpty()) {
            val cur = webView.url
            return if (cur.isNullOrEmpty() || cur == "about:blank") null else NativeSection.FEED
        }
        if (path == "/friends") pendingFriendsUserId = null
        if (path == "/communities") pendingCommunitiesUserId = null
        return when (path) {
            "/chats" -> NativeSection.CHATS
            "/friends" -> NativeSection.FRIENDS
            "/communities" -> NativeSection.COMMUNITIES
            else -> null
        }
    }

    /**
     * Нативная форма показывается только когда авторизация не подтверждена.
     * /login может быть открыт самим сайтом в процессе синхронизации localStorage;
     * не сбрасываем состояние и не показываем форму поверх уже подтверждённой сессии.
     */
    private fun syncLoginOverlay(view: WebView, url: String?) {
        if (pathOf(url) != LOGIN_PATH) {
            if (isLoggedIn == true || isPublicPath(url)) {
                loginController.hide()
            } else {
                hideNativeSection()
                loginController.show()
            }
            return
        }

        if (isLoggedIn == true) {
            loginController.hide()
            return
        }

        view.evaluateJavascript(
            "(function(){try{return localStorage.getItem('deviceId')||'';}catch(e){return '';}})()"
        ) { raw ->
            if (isFinishing || isDestroyed) return@evaluateJavascript
            val deviceId = unwrapJsString(raw).orEmpty()
            siteApi.userId = ""
            siteApi.setSession("", deviceId, view.settings.userAgentString)
            if (pathOf(webView.url) == LOGIN_PATH && isLoggedIn != true) {
                hideNativeSection()
                loginController.show()
            } else {
                loginController.hide()
            }
        }
    }

    /** После подтверждения кода проверяем серверную сессию и открываем нативную ленту. */
    private fun onNativeLoginSuccess(user: org.json.JSONObject) {
        val activeDeviceId = siteApi.deviceId.ifBlank { getOrCreateNativeDeviceId() }
        siteApi.setSession("", activeDeviceId, webView.settings.userAgentString)
        siteApi.io.execute {
            var confirmedUser: org.json.JSONObject? = null
            var explicitInvalid = false
            var verificationUnavailable = false
            try {
                val response = siteApi.get("/api/session/bootstrap")
                if (response.code == 200) {
                    val bootstrap = org.json.JSONObject(response.body)
                    if (bootstrap.optBoolean("authenticated", false)) {
                        confirmedUser = bootstrap.optJSONObject("user")
                    } else if (bootstrap.has("authenticated")) {
                        explicitInvalid = true
                    }
                } else if (response.code == 401) {
                    explicitInvalid = true
                } else {
                    verificationUnavailable = true
                }
            } catch (e: Exception) {
                verificationUnavailable = true
                Log.w(TAG, "Session bootstrap failed immediately after native login", e)
            }

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (explicitInvalid) {
                    siteApi.userId = ""
                    isLoggedIn = false
                    loginController.showLoginError("Сервер не подтвердил сессию после входа. Проверьте подключение и войдите снова.")
                    Log.w(TAG, "Native login returned success, but session bootstrap rejected the session")
                    return@runOnUiThread
                }

                val sessionUser = confirmedUser ?: user
                val id = sessionUser.optLong("id", user.optLong("id", 0L)).toString()
                if (id == "0") {
                    loginController.showLoginError("Сервер не вернул идентификатор пользователя")
                    return@runOnUiThread
                }
                siteApi.setSession(id, activeDeviceId, webView.settings.userAgentString)
                synchronized(this@MainActivity) {
                    authStateVersion++
                    pendingAuthInvalidCallbacks.clear()
                }
                isLoggedIn = true
                authRecheckPending = false
                autoLoginRedirectDone = false
                swipeRefresh.visibility = View.GONE
                webView.visibility = View.GONE
                offlineView.visibility = View.GONE
                loginController.hide()
                returnSection = null
                navFrames.clear()
                showNativeSection(NativeSection.FEED)
                if (verificationUnavailable) {
                    Log.w(TAG, "Could not verify session after login; opening native feed using login response")
                }
            }
        }
    }


    /** Восстанавливает сессию напрямую через API, не загружая сайт в WebView. */
    private fun restoreNativeSession() {
        val did = getOrCreateNativeDeviceId()
        val ua = webView.settings.userAgentString
        siteApi.setSession("", did, ua)
        siteApi.io.execute {
            var user: org.json.JSONObject? = null
            try {
                val response = siteApi.get("/api/session/bootstrap")
                if (response.code == 200) {
                    val body = org.json.JSONObject(response.body)
                    if (body.optBoolean("authenticated", false)) user = body.optJSONObject("user")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Native session restore failed", e)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val restored = user
                val id = restored?.optLong("id", 0L) ?: 0L
                if (id > 0L) {
                    siteApi.setSession(id.toString(), did, ua)
                    isLoggedIn = true
                    loginController.hide()
                    swipeRefresh.visibility = View.GONE
                    webView.visibility = View.GONE
                    showNativeSection(NativeSection.FEED)
                } else {
                    isLoggedIn = false
                    loginController.show()
                }
            }
        }
    }

    /** Постоянный UUID приложения: один и тот же для запроса входа и проверки сессии. */
    private fun getOrCreateNativeDeviceId(): String {
        val prefs = getSharedPreferences("fortport_native_session", MODE_PRIVATE)
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrBlank()) return existing
        val created = java.util.UUID.randomUUID().toString()
        prefs.edit().putString("device_id", created).apply()
        return created
    }

    /** Показывает WebView только для вспомогательных страниц без нативной реализации. */
    private fun openWebPage(url: String) {
        hideNativeSection()
        swipeRefresh.visibility = View.VISIBLE
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun openLoginPage() {
        swipeRefresh.visibility = View.GONE
        webView.visibility = View.GONE
        loginController.showLoginError("")
    }

    /** При первом входе (сессии нет) сразу ведём на страницу авторизации. */
    private fun redirectToLoginIfNeeded() {
        if (autoLoginRedirectDone) return
        if (isPublicPath(webView.url)) return
        autoLoginRedirectDone = true
        openLoginPage()
    }

    /**
     * Нативное меню профиля (PopupMenu) — дублирует пункты из #user-dropdown
     * сайта (auth.js), поскольку сам #user-dropdown теперь недоступен: он
     * физически находится внутри скрытого #main-top-bar, а display:none на
     * родителе скрывает потомков безусловно, что бы мы ни делали с классом
     * .show у самого дропдауна.
     */
    private fun showProfileMenu(anchor: View) {
        val items = listOf(
            "Мой профиль" to "/profile",
            "Настройки" to "/settings",
            "Поддержка" to "/support",
            "О нас" to "/about",
            "Конфиденциальность" to "/privacy",
            "Условия" to "/terms",
            "Выйти" to null
        )
        val popup = PopupMenu(this, anchor)
        items.forEachIndexed { index, (label, _) -> popup.menu.add(0, index, index, label) }
        popup.setOnMenuItemClickListener { menuItem ->
            val (_, path) = items[menuItem.itemId]
            if (path == "/settings") {
                openNativeSettings()
            } else if (siteApi.isDemo) {
                when (path) {
                    null -> leaveDemo()
                    "/profile" -> openNativeProfile(siteApi.userId.toLongOrNull() ?: 0L)
                    else -> Toast.makeText(this, "Недоступно в тестовом режиме", Toast.LENGTH_SHORT).show()
                }
            } else if (path == null) {
                webView.evaluateJavascript(
                    "if (typeof logout === 'function') { logout(); }",
                    null
                )
            } else {
                // Сначала используем штатную ссылку сайта: на некоторых страницах
                // переходы обрабатываются JavaScript-кодом сайта. Прямой loadUrl()
                // обходит обработчик ссылки и может оставить профиль на спиннере.
                val targetPath = path
                val targetUrl = "$SITE_ORIGIN$targetPath"
                val jsPath = targetPath.replace("\\", "\\\\").replace("'", "\\'")
                webView.evaluateJavascript("""
                    (function() {
                        var wanted = '$jsPath';
                        var links = Array.prototype.slice.call(document.querySelectorAll('#user-dropdown a[href], a[href]'));
                        var link = links.find(function(a) {
                            try { return new URL(a.href, location.href).pathname.replace(/\/$/, '') === wanted.replace(/\/$/, ''); }
                            catch (e) { return false; }
                        });
                        if (link) { link.click(); return 'clicked'; }
                        location.href = '$targetUrl';
                        return 'fallback';
                    })();
                """.trimIndent()) { result ->
                    Log.d(TAG, "Переход из меню профиля на $targetPath: $result")
                }
            }
            true
        }
        popup.show()
    }

    /**
     * Не сбрасываем авторизацию по одной ошибке отдельного API-запроса.
     * Logout выполняется только если bootstrap явно подтвердил отсутствие сессии.
     * Тайм-ауты, 403 и 5xx сохраняют текущее состояние и экран.
     */
    private fun confirmSessionBeforeLogout(onConfirmedInvalid: (() -> Unit)? = null) {
        val version: Int
        synchronized(this) {
            if (onConfirmedInvalid != null) pendingAuthInvalidCallbacks.add(onConfirmedInvalid)
            if (authConfirmationInFlight) return
            authConfirmationInFlight = true
            version = authStateVersion
        }

        siteApi.io.execute {
            val confirmedInvalid = siteApi.confirmSessionInvalid()
            runOnUiThread {
                val callbacks: List<() -> Unit>
                synchronized(this) {
                    authConfirmationInFlight = false
                    if (version != authStateVersion) {
                        pendingAuthInvalidCallbacks.clear()
                        return@runOnUiThread
                    }
                    callbacks = pendingAuthInvalidCallbacks.toList()
                    pendingAuthInvalidCallbacks.clear()
                }

                if (confirmedInvalid) {
                    authRecheckPending = false
                    isLoggedIn = false
                    updateBarsVisibility()
                    if (callbacks.isNotEmpty()) callbacks.forEach { it() }
                    else redirectToLoginIfNeeded()
                } else {
                    Log.w(TAG, "Session invalidation was not confirmed; keeping current session")
                }
            }
        }
    }

    /**
     * Баланс и покупка CD-Coins используют same-origin API. Асинхронный fetch
     * возвращает результат в Android через JavascriptInterface: evaluateJavascript
     * сам по себе не ожидает завершения Promise.
     */
    private fun refreshCdCoinsBalance() {
        val js = """
            (function() {
              fetch('/api/payments/balance', {credentials: 'same-origin'})
                .then(function(r) {
                  if (r.status === 401 || r.status === 403) { AndroidNav.onAuthState(false); throw new Error('HTTP ' + r.status); }
                  if (!r.ok) throw new Error('HTTP ' + r.status);
                  AndroidNav.onAuthState(true);
                  return r.json();
                })
                .then(function(data) { AndroidNav.onCoinsBalance(JSON.stringify(data)); })
                .catch(function(e) { AndroidNav.onCoinsBalanceError(String(e)); });
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private data class CdCoinOption(
        val id: Int,
        val label: String,
        val formattedPrice: String
    )

    private fun showCdCoinsPurchaseDialog() {
        val js = """
            (function() {
              fetch('/api/payments/options', {credentials: 'same-origin'})
                .then(function(r) {
                  if (!r.ok) throw new Error('HTTP ' + r.status);
                  return r.json();
                })
                .then(function(data) { AndroidNav.onCoinsOptions(JSON.stringify(data)); })
                .catch(function(e) { AndroidNav.onCoinsOptionsError(String(e)); });
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun handleCdCoinsOptions(json: String) {
        if (isFinishing || isDestroyed) return
        try {
            val data = org.json.JSONObject(json)
            if (!data.optBoolean("enabled", false)) {
                showCdCoinsError("Покупка CD-Coins сейчас недоступна.")
                return
            }
            val array = data.optJSONArray("options") ?: org.json.JSONArray()
            val options = (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val id = item.optInt("id", -1)
                val label = item.optString("label", "")
                val price = item.optString("formatted", "")
                if (id < 0 || label.isBlank() || price.isBlank()) null
                else CdCoinOption(id, label, price)
            }
            if (options.isEmpty()) {
                showCdCoinsError("Сейчас нет доступных вариантов пополнения.")
                return
            }
            val labels = options.map { "${it.label} — ${it.formattedPrice}" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Пополнение CD-Coins")
                .setItems(labels) { _, which -> createCdCoinsPayment(options[which]) }
                .setNegativeButton("Отмена", null)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка обработки вариантов CD-Coins", e)
            showCdCoinsError("Не удалось обработать варианты пополнения.")
        }
    }

    private fun createCdCoinsPayment(option: CdCoinOption) {
        val js = """
            (function() {
              fetch('/api/payments/create', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({optionId: ${option.id}})
              }).then(function(r) {
                return r.json().catch(function() { return {}; }).then(function(data) {
                  if (!r.ok) throw new Error(data.message || data.error || ('HTTP ' + r.status));
                  return data;
                });
              }).then(function(data) { AndroidNav.onCoinsPayment(JSON.stringify(data)); })
                .catch(function(e) { AndroidNav.onCoinsPaymentError(String(e)); });
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun handleCdCoinsPayment(json: String) {
        if (isFinishing || isDestroyed) return
        try {
            val data = org.json.JSONObject(json)
            val confirmationUrl = data.optString("confirmationUrl", "")
            val uri = android.net.Uri.parse(confirmationUrl)
            val host = uri.host.orEmpty().lowercase()
            if (uri.scheme != "https" || host !in setOf("yoomoney.ru", "fortport.ru")) {
                val error = data.optString("message", data.optString("error", ""))
                showCdCoinsError(if (error.isNotBlank()) "Не удалось создать платёж. $error"
                    else "Сервер не вернул корректную ссылку на оплату.")
                return
            }
            openPaymentWebView(confirmationUrl)
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка создания платежа CD-Coins", e)
            showCdCoinsError("Не удалось обработать ответ платежа. Попробуйте ещё раз.")
        }
    }

    /**
     * Показывает платёж в отдельном WebView внутри Activity.
     * Основной WebView остаётся в памяти на прежней странице: это сохраняет SPA/DOM-состояние
     * и не заставляет пользователя заново авторизовываться после возврата из платёжной формы.
     * CookieManager общий для WebView приложения; third-party cookies разрешены для 3-D Secure.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun openPaymentWebView(url: String) {
        if (paymentWebView != null) {
            paymentWebView?.loadUrl(url)
            return
        }

        val root = findViewById<ViewGroup>(R.id.rootLayout)
        val container = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.WHITE)
            elevation = 30f * resources.displayMetrics.density
            layoutParams = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val payProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.VISIBLE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (3 * resources.displayMetrics.density).toInt().coerceAtLeast(3),
                android.view.Gravity.TOP
            )
        }
        val payWebView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.userAgentString = webView.settings.userAgentString
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    return when (uri.scheme?.lowercase()) {
                        "https", "http" -> false // платёжные редиректы и 3-D Secure остаются в приложении
                        "tel", "mailto" -> {
                            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: Exception) {
                                Log.w(TAG, "Не удалось открыть ссылку из платёжной формы", e)
                            }
                            true
                        }
                        else -> true
                    }
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    payProgress.visibility = View.VISIBLE
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    payProgress.visibility = View.GONE
                    CookieManager.getInstance().flush()
                    val finishedUri = Uri.parse(url ?: "")
                    Log.d(TAG, "Страница оплаты загружена: " + finishedUri.host + finishedUri.path)

                    // Некоторые кнопки выхода из платёжной формы ведут на API FortPort,
                    // который без отдельной авторизации показывает JSON {error: "not authenticated"}.
                    // Даём адресу загрузиться (чтобы сервер обработал переход), а затем
                    // возвращаем пользователя на главную сайта в основном WebView.
                    if (finishedUri.host.equals(SITE_HOST, ignoreCase = true) &&
                        finishedUri.path.orEmpty().startsWith("/api/")) {
                        Log.i(TAG, "Выход из оплаты на API-страницу; возвращаемся на главную")
                        closePaymentWebView()
                        if (isLoggedIn == true) showNativeSection(NativeSection.FEED)
                        else openWebPage(SITE_ORIGIN + "/")
                    }
                }

                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    super.onReceivedError(view, request, error)
                    if (request.isForMainFrame) {
                        payProgress.visibility = View.GONE
                        Log.e(TAG, "Ошибка загрузки платёжной страницы: " + error.description)
                    }
                }
            }
        }
        container.addView(payWebView)
        container.addView(payProgress)
        root.addView(container)

        paymentWebView = payWebView
        paymentContainer = container
        paymentProgress = payProgress
        // В платёжном режиме прячем обе нативные панели и отключаем pull-to-refresh.
        topNavBar.visibility = View.GONE
        sectionHeader.visibility = View.GONE
        bottomNavBar.visibility = View.GONE
        swipeRefresh.isEnabled = false
        swipeRefresh.visibility = View.GONE
        progressBar.visibility = View.GONE
        CookieManager.getInstance().flush()
        payWebView.loadUrl(url)
    }

    private fun closePaymentWebView() {
        val payWebView = paymentWebView ?: return
        paymentWebView = null
        paymentProgress = null
        paymentContainer?.let { (it.parent as? ViewGroup)?.removeView(it) }
        paymentContainer = null
        payWebView.stopLoading()
        payWebView.webChromeClient = null
        payWebView.webViewClient = WebViewClient()
        payWebView.destroy()
        swipeRefresh.visibility = View.VISIBLE
        swipeRefresh.isEnabled = true
        updateBarsVisibility()
        CookieManager.getInstance().flush()
        refreshCdCoinsBalance()
    }

    private fun showCdCoinsError(message: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this)
            .setTitle("CD-Coins")
            .setMessage(message)
            .setPositiveButton("ОК", null)
            .show()
    }

    /**
     * Подтягивает текущую аватарку из localStorage.userAvatar (её выставляет
     * сайт после логина, см. updateAuthButtons() в auth.js) и загружает
     * картинку в фоновом потоке.
     */
    private fun loadProfileAvatar() {
        webView.evaluateJavascript(
            "(localStorage.getItem('userAvatar') || '');"
        ) { rawResult ->
            val path = unwrapJsString(rawResult)?.trim().orEmpty()
            val custom = path.isNotEmpty() && path != "null" && path != "undefined"
            if (custom) {
                val url = if (path.startsWith("http")) path else "$SITE_ORIGIN$path"
                fetchBitmapAsync(url) { bitmap ->
                    if (bitmap != null) navProfileAvatar.setImageBitmap(bitmap) else showDefaultAvatar()
                }
            } else {
                showDefaultAvatar() // аватар ещё не выбран владельцем аккаунта
            }
        }
    }

    /**
     * Аватар по умолчанию: сначала assets/default-avatar.jpg (если положить файл в APK),
     * затем /default-avatar.jpg с сайта, а если и это не вышло — нарисованный заполнитель.
     */
    private fun showDefaultAvatar() {
        loadAssetIcon("default-avatar.jpg")?.let {
            navProfileAvatar.setImageBitmap(it)
            return
        }
        navProfileAvatar.setImageResource(R.drawable.avatar_placeholder)
        fetchBitmapAsync("$SITE_ORIGIN/default-avatar.jpg") { bitmap ->
            if (bitmap != null) navProfileAvatar.setImageBitmap(bitmap)
        }
    }

    /** evaluateJavascript возвращает строку в виде JSON-литерала — снимаем кавычки/экранирование. */
    private fun unwrapJsString(raw: String?): String? {
        if (raw == null || raw == "null") return null
        var s = raw
        if (s.length >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length - 1)
        }
        return s.replace("\\\"", "\"").replace("\\\\", "\\")
    }

    private fun fetchBitmapAsync(url: String, onResult: (Bitmap?) -> Unit) {
        Thread {
            val bitmap = try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.inputStream.use { BitmapFactory.decodeStream(it) }
            } catch (e: Exception) {
                Log.w(TAG, "Не удалось загрузить аватар: $url", e)
                null
            }
            runOnUiThread { onResult(bitmap) }
        }.start()
    }

    /**
     * Открывает форму создания поста через уже существующую на сайте функцию
     * window.openPostCreator() (post.js). Если она не определена на текущей
     * странице (эта функция доступна не на каждом экране сайта) — сначала
     * переходим на ленту и открываем форму сразу после её загрузки.
     */
    /** Нативное окно нового поста: на ленте (с выбором порта) и на своей странице. */
    private fun openNativeComposer() {
        val section = nativeSection
        val onFeed = section == NativeSection.FEED
        val onPort = section == NativeSection.PORT
        val host: PostHost = when {
            onFeed -> feedController
            onPort -> portController
            else -> profileController
        }
        PostComposer.show(
            host = host,
            pickFile = { done -> commentPickCb = done; commentPicker.launch("*/*") },
            fixedCommunity = if (onPort) pendingCommunityId else null,
            allowChoice = onFeed,
            onPosted = { host.reloadList() }
        )
    }

    private fun openPostCreator() {
        if (nativeSection == NativeSection.FEED || nativeSection == NativeSection.PROFILE || nativeSection == NativeSection.PORT) {
            openNativeComposer()
            return
        }
        // Форма поста штатно работает только на ленте. На любой другой вкладке
        // (музыка, чаты и т.д.) её скрипты не подгружены/не готовы и WebView
        // выдаёт ошибку, поэтому сначала переходим на ленту и открываем форму
        // тем же путём, что и на главной странице.
        // Если на текущей странице (профиль, порт/сообщество и т.д.) форма поста
        // уже есть — открываем её здесь же, не уводя пользователя на ленту: так
        // сайт публикует пост в контексте этой страницы. Только если функции нет
        // (музыка, чаты...) — переходим на ленту.
        webView.evaluateJavascript("typeof window.openPostCreator === 'function'") { result ->
            if (result == "true") {
                runOpenPostCreatorJs()
            } else {
                pendingOpenPostCreator = true
                openWebPage("$SITE_ORIGIN/main")
            }
        }
    }

    /** Вызывает openPostCreator() сайта; если скрипт ещё не готов — повторяет до ~3 секунд. */
    private fun runOpenPostCreatorJs() {
        webView.evaluateJavascript("""
            (function() {
                var tries = 0;
                (function attempt() {
                    if (typeof openPostCreator === 'function') {
                        try { openPostCreator(); } catch (e) {}
                    } else if (tries++ < 15) {
                        setTimeout(attempt, 200);
                    }
                })();
            })();
        """.trimIndent(), null)
    }

    /** Разделы, где публиковать пост нельзя: вместо кнопки "+" — пустое место между двумя разделителями. */
    private val NO_POST_PATH_PREFIXES = listOf("/music", "/communities", "/friends", "/chats")

    private fun updateAddPostButton(url: String?) {
        currentUrl = url
        val path = pathOf(url)
        val ownProfile = nativeSection == NativeSection.PROFILE &&
            (pendingProfileId == 0L || pendingProfileId.toString() == siteApi.userId)
        val portPost = nativeSection == NativeSection.PORT && portController.canPost
        val noPost = (nativeSection != null && nativeSection != NativeSection.FEED && !ownProfile && !portPost) || NO_POST_PATH_PREFIXES.any { path == it || path.startsWith("$it/") }
        // INVISIBLE (а не GONE) сохраняет ширину кнопки — это и есть пустое место по центру.
        findViewById<View>(R.id.navAddPost).visibility = if (noPost) View.INVISIBLE else View.VISIBLE
        val dividerVis = if (noPost) View.VISIBLE else View.GONE
        findViewById<View>(R.id.navGapDividerLeft).visibility = dividerVis
        findViewById<View>(R.id.navGapDividerRight).visibility = dividerVis
        // В разделах с нативной шапкой «Домой» занимает место кнопки поста
        // (шапка заменяет верхнюю панель, где раньше была кнопка «Домой»).
        val hasSectionChrome = activeSectionChrome() != null
        navHomeCenter.visibility = if (hasSectionChrome) View.VISIBLE else View.GONE
        if (paymentWebView == null) applyTopChrome(barsShouldShow())
    }

    private fun hideBottomNav() {
        if (bottomNavBar.translationY == 0f) {
            bottomNavBar.animate().translationY(bottomNavBar.height.toFloat()).setDuration(200).start()
        }
    }

    private fun showBottomNav() {
        if (bottomNavBar.translationY != 0f) {
            bottomNavBar.animate().translationY(0f).setDuration(200).start()
        }
    }

    /**
     * Мост JS -> Android: авто-скрытие нижней панели при скролле ленты и
     * обновление бейджа уведомлений на нативной кнопке колокольчика (сайт
     * сам считает это число в updateNotificationBadge(), auth.js — мы просто
     * читаем готовый результат из DOM, см. injectNavCleanup()).
     */
    private inner class ScrollBridge {
        @JavascriptInterface
        fun onScroll(direction: String) {
            runOnUiThread {
                if (direction == "down") hideBottomNav() else showBottomNav()
            }
        }

        @JavascriptInterface
        fun openNativeChat(json: String) {
            runOnUiThread {
                reloadChatsOnResume = true
                startActivity(
                    Intent(this@MainActivity, ChatActivity::class.java)
                        .putExtra(ChatActivity.EXTRA_PAYLOAD, json)
                )
            }
        }

        @JavascriptInterface
        fun onNotifCount(countText: String) {
            runOnUiThread {
                if (countText.isBlank()) {
                    navNotifBadge.visibility = View.GONE
                } else {
                    navNotifBadge.text = countText
                    navNotifBadge.visibility = View.VISIBLE
                }
            }
        }

        @JavascriptInterface
        fun onCoinsBalance(json: String) {
            runOnUiThread {
                try {
                    val formatted = org.json.JSONObject(json).optString("formatted", "")
                    if (formatted.isNotBlank()) navCoinsValue.text = formatted
                } catch (e: Exception) {
                    Log.w(TAG, "Не удалось разобрать баланс CD-Coins", e)
                }
            }
        }

        @JavascriptInterface
        fun onAuthState(loggedIn: Boolean) {
            runOnUiThread {
                if (loggedIn) {
                    synchronized(this@MainActivity) {
                        authStateVersion++
                        pendingAuthInvalidCallbacks.clear()
                    }
                    authRecheckPending = false
                    isLoggedIn = true
                    updateBarsVisibility()
                    return@runOnUiThread
                }

                // 401/403 от balance API — не доказательство завершения сессии:
                // это может быть временный отказ, WAF или проблема маршрута.
                confirmSessionBeforeLogout()
            }
        }

        @JavascriptInterface
        fun onCoinsBalanceError(error: String) {
            Log.w(TAG, "Не удалось загрузить баланс CD-Coins: $error")
        }

        @JavascriptInterface
        fun onCoinsOptions(json: String) {
            runOnUiThread { handleCdCoinsOptions(json) }
        }

        @JavascriptInterface
        fun onCoinsOptionsError(error: String) {
            Log.w(TAG, "Не удалось загрузить варианты CD-Coins: $error")
            runOnUiThread {
                showCdCoinsError("Не удалось загрузить варианты пополнения. Проверьте подключение и авторизацию.")
            }
        }

        @JavascriptInterface
        fun onCoinsPayment(json: String) {
            runOnUiThread { handleCdCoinsPayment(json) }
        }

        @JavascriptInterface
        fun onCoinsPaymentError(error: String) {
            Log.e(TAG, "Ошибка создания платежа CD-Coins: $error")
            runOnUiThread { showCdCoinsError("Не удалось создать платёж. $error") }
        }
    }

    /**
     * Отслеживаем скролл в document.addEventListener(..., true) — то есть
     * на фазе перехвата (capture), а не всплытия. Это единственный надёжный
     * способ поймать scroll-события из ЛЮБОГО вложенного прокручиваемого
     * блока на странице (а не только из window), не зная заранее точный
     * класс/id контейнера ленты на сайте, который может ещё и поменяться.
     */
    private fun injectScrollTracking(view: WebView) {
        val js = """
            (function() {
                if (window.__fortportScrollHooked) return;
                window.__fortportScrollHooked = true;
                var lastTop = {};
                var threshold = 8;
                function handle(e) {
                    var el = (e.target === document) ? (document.scrollingElement || document.documentElement) : e.target;
                    if (!el) return;
                    var top = (typeof el.scrollTop === 'number') ? el.scrollTop : window.scrollY;
                    var key = (el.id || el.className || 'win') + '';
                    var prev = lastTop[key];
                    if (prev === undefined) { lastTop[key] = top; return; }
                    var delta = top - prev;
                    if (Math.abs(delta) < threshold) return;
                    lastTop[key] = top;
                    if (window.AndroidNav) {
                        window.AndroidNav.onScroll(delta > 0 ? 'down' : 'up');
                    }
                }
                document.addEventListener('scroll', handle, true);
                window.addEventListener('scroll', handle, true);
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    /**
     * Мост JS -> Android для нативного просмотра фото: страница вызывает
     * AndroidPhoto.open(json), мы запускаем PhotoViewerActivity.
     */
    private inner class PhotoBridge {
        @JavascriptInterface
        fun open(json: String) {
            runOnUiThread {
                startActivity(
                    Intent(this@MainActivity, PhotoViewerActivity::class.java)
                        .putExtra(PhotoViewerActivity.EXTRA_PAYLOAD, json)
                )
            }
        }
    }

    /**
     * Подменяет window.openLightbox (его вызывают клики по фото в постах,
     * вложениям комментариев и аватаркам, см. client.js/display-post.js) так,
     * чтобы вместо веб-оверлея открывался нативный просмотрщик.
     *
     * Через defineProperty, а не простое присваивание: если client.js
     * присвоит window.openLightbox позже нашей подмены, оригинал всё равно
     * окажется в замыкании (fallback на случай, если мост недоступен).
     */
    private fun injectPhotoViewerHook(view: WebView) {
        val js = """
            (function() {
                if (window.__fpPhotoHooked || !window.AndroidPhoto) return;
                window.__fpPhotoHooked = true;
                var orig = window.openLightbox;

                function abs(p) {
                    try { return new URL(String(p), location.origin).href; } catch (e) { return ''; }
                }
                function norm(it) {
                    if (!it) return null;
                    if (typeof it === 'string') {
                        var m = it.match(/^\/photo\/(\d+)/);
                        return { url: abs(it), type: 'image', mediaId: m ? Number(m[1]) : null };
                    }
                    var raw = it.path || it.url || '';
                    var m2 = String(raw).match(/^\/photo\/(\d+)/);
                    var id = Number(it.mediaId || it.photoId || (m2 && m2[1]) || 0) || null;
                    var t = (it.type === 'video' || it.type === 'gif') ? it.type : 'image';
                    return { url: abs(raw), type: t, mediaId: id };
                }

                function hooked(src, items) {
                    try {
                        var first = norm(src);
                        if (!first || !first.url) throw new Error('no url');
                        var list = (Array.isArray(items) && items.length ? items.map(norm) : [first])
                            .filter(function (x) { return x && x.url; });
                        var idx = -1;
                        list.forEach(function (x, i) {
                            if (idx < 0 && ((first.mediaId && x.mediaId && first.mediaId === x.mediaId) || x.url === first.url)) idx = i;
                        });
                        if (idx < 0) { list.unshift(first); idx = 0; }
                        window.AndroidPhoto.open(JSON.stringify({
                            items: list,
                            index: idx,
                            deviceId: (function () { try { return localStorage.getItem('deviceId') || ''; } catch (e) { return ''; } })(),
                            ua: navigator.userAgent
                        }));
                        return;
                    } catch (e) { /* падаем обратно на штатный лайтбокс сайта */ }
                    if (typeof orig === 'function') return orig.apply(this, arguments);
                }

                Object.defineProperty(window, 'openLightbox', {
                    configurable: true,
                    get: function () { return hooked; },
                    set: function (fn) { orig = fn; }
                });
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    /**
     * Прячет тёмную строку служебных ссылок вверху страницы (#utility-bar —
     * Настройки/Поддержка/О нас/Конфиденциальность/Условия, создаётся в
     * createUtilityBar() в auth.js) и переносит эти же пункты (кроме
     * "Настройки" — он там уже есть) в выпадающее меню у аватарки
     * (#user-dropdown, туда же, где "Мой профиль"/"Настройки"/"Выйти").
     *
     * Сайт пересоздаёт оба блока через JS при каждой загрузке страницы
     * (и возможно повторно без полной перезагрузки — после логина/логаута),
     * поэтому держим MutationObserver, а не добавляем пункты один раз.
     */
    private fun injectNavCleanup(view: WebView) {
        val js = """
            (function() {
                if (!document.getElementById('fortport-client-nav-cleanup')) {
                    var style = document.createElement('style');
                    style.id = 'fortport-client-nav-cleanup';
                    style.textContent = '#utility-bar, #main-top-bar { display: none !important; }';
                    document.head.appendChild(style);
                }

                function addUtilityLinksToDropdown() {
                    var dropdown = document.getElementById('user-dropdown');
                    if (!dropdown) return;
                    if (dropdown.querySelector('.fortport-client-extra-link')) return;
                    var divider = dropdown.querySelector('.dropdown-divider');
                    var links = [
                        ['/support', 'Поддержка'],
                        ['/about', 'О нас'],
                        ['/privacy', 'Конфиденциальность'],
                        ['/terms', 'Условия']
                    ];
                    var frag = document.createDocumentFragment();
                    links.forEach(function(pair) {
                        var a = document.createElement('a');
                        a.href = pair[0];
                        a.className = 'dropdown-item fortport-client-extra-link';
                        a.textContent = pair[1];
                        frag.appendChild(a);
                    });
                    if (divider) {
                        dropdown.insertBefore(frag, divider);
                    } else {
                        dropdown.appendChild(frag);
                    }
                }

                addUtilityLinksToDropdown();

                // Бейдж на родном колокольчике сайта считает сам (updateNotificationBadge()
                // в auth.js) — мы лишь читаем готовое число из DOM и пробрасываем в нативную
                // кнопку, т.к. сам колокольчик сайта теперь скрыт вместе с #main-top-bar.
                var lastNotifText = null;
                function reportNotifBadge() {
                    var badge = document.querySelector('.user-notifs .notification-badge');
                    var text = (badge && badge.style.display !== 'none') ? badge.textContent : '';
                    if (text === lastNotifText) return;
                    lastNotifText = text;
                    if (window.AndroidNav) {
                        window.AndroidNav.onNotifCount(text);
                    }
                }

                reportNotifBadge();

                if (!window.__fortportNavObserverSet) {
                    window.__fortportNavObserverSet = true;
                    var observer = new MutationObserver(function() {
                        addUtilityLinksToDropdown();
                        reportNotifBadge();
                    });
                    observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true });
                }
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun loadSite() {
        if (isNetworkAvailable()) {
            offlineView.visibility = View.GONE
            if (isLoggedIn == true) {
                swipeRefresh.visibility = View.GONE
                webView.visibility = View.GONE
                showNativeSection(NativeSection.FEED)
            } else {
                swipeRefresh.visibility = View.GONE
                webView.visibility = View.GONE
                loginController.show()
            }
        } else {
            showOffline()
        }
    }

    private fun showOffline() {
        if (siteApi.isDemo) return // тестовый режим работает без сети
        offlineView.visibility = View.VISIBLE
    }

    /**
     * Картинка для плашки "не удалось подключиться к серверу" — отдельные
     * файлы под светлую/тёмную тему, добавлены в assets/ui/logos/ как
     * net_failconnect_day.png / net_failconnect_dark.png. Смена темы
     * пересоздаёт Activity (configChanges не перехватывает uiMode), так что
     * достаточно выставить картинку один раз в onCreate.
     */
    private fun loadOfflineImage() {
        val isNight = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val path = if (isNight) "ui/logos/net_failconnect_dark.png" else "ui/logos/net_failconnect_day.png"
        offlineImage.setImageBitmap(loadAssetIcon(path))
    }

    /**
     * Убирает "; wv" из стандартного User-Agent WebView и следит, чтобы строка
     * заканчивалась как у обычного мобильного Chrome ("Mobile Safari/...").
     * Многие сайты определяют мобильную/десктопную вёрстку именно по этим
     * маркерам, поэтому такой User-Agent надёжнее заставляет их отдавать
     * мобильную версию интерфейса.
     */
    private fun buildMobileUserAgent(defaultUa: String): String {
        var ua = defaultUa.replace("; wv", "")
        if (!ua.contains("Mobile Safari")) {
            ua = ua.replace("Safari/", "Mobile Safari/")
        }
        return ua
    }

    /**
     * Страховка на случай, если конкретная версия WebView всё же не применит
     * мобильный @media-запрос сайта (@media (max-width: 830px) в base.css,
     * который делает .new-post-modal / .flag-modal / .add-lightbox шириной
     * 100%). Добавляем те же самые правила через <style> с !important —
     * они либо совпадут с уже применёнными сайтом (без видимого эффекта),
     * либо исправят раскладку, если по каким-то причинам сайт их не применил.
     * Условие window.innerWidth <= 830 не даёт правилу повлиять на настоящий
     * десктоп, если пользователь когда-нибудь откроет тот же движок на большом
     * экране (Chromebook, планшет в альбомной ориентации и т.п.).
     *
     * Этим же стилем прячем родные мобильные элементы сайта, которые теперь
     * дублируют нашу нижнюю панель: плавающую кнопку публикации поста
     * (.new-post-fab) и строку кнопок под шапкой (.nav-left-links, вместе
     * с .chats-toggle-btn внутри неё) — на мобильной вёрстке сайта это и
     * есть та самая "панель сверху" и "кнопка сбоку".
     */
    private fun injectMobileLayoutSafetyNet(view: WebView) {
        val js = """
            (function() {
                if (document.getElementById('fortport-client-safety-net')) return;
                if (window.innerWidth > 830) return;
                var style = document.createElement('style');
                style.id = 'fortport-client-safety-net';
                style.textContent = '.new-post-modal, .flag-modal, .add-lightbox {' +
                    'width: 100% !important;' +
                    'max-width: 100% !important;' +
                    'max-height: calc(100dvh - 20px) !important;' +
                    'box-sizing: border-box !important;' +
                '}' +
                '.new-post-fab, .nav-left-links {' +
                    'display: none !important;' +
                '}';
                document.head.appendChild(style);
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onBackPressed() {
        if (loginController.handleBack()) return
        val payWebView = paymentWebView
        if (payWebView != null) {
            if (payWebView.canGoBack()) {
                payWebView.goBack()
            } else {
                closePaymentWebView()
            }
            return
        }
        // «Точка невозврата»: после входа нативные разделы — корень приложения (WebView скрыт).
        // Если вернуться некуда (нет стека переходов и родителя у поста), «назад» не должно
        // прятать раздел и оставлять пустой экран: из ленты сворачиваем приложение, из остальных
        // корневых разделов возвращаемся в ленту.
        if (isLoggedIn == true && nativeSection != null && webView.visibility != View.VISIBLE) {
            val canStepBack = navFrames.isNotEmpty() ||
                (nativeSection == NativeSection.POST && postParent != null)
            if (!canStepBack) {
                if (nativeSection == NativeSection.FEED) {
                    moveTaskToBack(true)
                } else {
                    returnSection = null
                    showNativeSection(NativeSection.FEED)
                }
                return
            }
        }
        if (nativeSection == NativeSection.NOTIFS) {
            if (popNavFrame()) return
            hideNativeSection()
            return
        }
        if (nativeSection == NativeSection.PORT) {
            if (popNavFrame()) return
            hideNativeSection()
            if (pathOf(webView.url) == "/community") handleHistoryBack()
            return
        }
        if (nativeSection == NativeSection.SETTINGS) {
            if (popNavFrame()) return
            hideNativeSection()
            if (pathOf(webView.url) == "/settings") handleHistoryBack()
            return
        }
        if (nativeSection == NativeSection.PROFILE) {
            if (popNavFrame()) return
            hideNativeSection()
            // Профиль открыли ссылкой/меню/JS-переходом сайта: идём назад по истории WebView.
            if (pathOf(webView.url) == "/profile") handleHistoryBack()
            return
        }
        if ((nativeSection == NativeSection.MUSIC || nativeSection == NativeSection.FRIENDS ||
                nativeSection == NativeSection.COMMUNITIES) && navFrames.isNotEmpty()) {
            if (popNavFrame()) return
        }
        if (nativeSection == NativeSection.POST) {
            val parent = postParent
            if (parent != null) {
                postParent = null
                showNativeSection(parent) // лента остаётся на прежней позиции
                if (parent == NativeSection.FEED) feedController.refreshCards()
                if (parent == NativeSection.PROFILE) profileController.refreshCards()
                if (parent == NativeSection.PORT) portController.refreshCards()
                return
            }
            hideNativeSection()
            // Пост открыли ссылкой/JS-переходом сайта: если WebView тоже ушёл на /post — идём назад по истории.
            if (pathOf(webView.url) == "/post") handleHistoryBack()
            return
        }
        if (nativeSection != null) {
            hideNativeSection()
            // Под списком может лежать веб-версия /chats или /friends — тогда идём назад по истории.
            if (pathOf(webView.url) !in setOf("/chats", "/friends", "/communities", "/music")) return
        } else if (returnSection != null && pathOf(webView.url) in setOf("/profile", "/community", "/new_community", "/post", "/settings", "/friends", "/communities", "/community/settings")) {
            // Профиль/порт открыли из нативного списка — «Назад» возвращает в него.
            val back = returnSection!!
            returnSection = null
            if (back == NativeSection.POST) {
                pendingPostId = postReturnId
                pendingPost = null
            }
            if (back == NativeSection.PROFILE) pendingProfileId = returnProfileId
            if (back == NativeSection.PORT) pendingCommunityId = returnPortId
            if (webView.canGoBack()) {
                // Страница под профилем — главная: её адрес не должен вытеснить вернувшийся пост/профиль лентой.
                if (back == NativeSection.POST || back == NativeSection.PROFILE || back == NativeSection.PORT) skipNativeNavOnce = true
                webView.goBack()
            }
            showNativeSection(back)
            return
        }
        handleHistoryBack()
    }

    private fun handleHistoryBack() {
        if (webView.canGoBack()) {
            val list = webView.copyBackForwardList()
            var target = list.currentIndex - 1
            // Уже вошли — страницы входа/регистрации в истории пропускаем.
            if (isLoggedIn == true) {
                while (target >= 0 && isAuthPage(list.getItemAtIndex(target).url)) target--
            }
            // Открытие/закрытие нативного чата оставляет в истории дубли /chats — пропускаем их.
            val currentChatsUrl = list.getItemAtIndex(list.currentIndex).url
            if (currentChatsUrl != null && Uri.parse(currentChatsUrl).path.orEmpty().trimEnd('/') == "/chats") {
                while (target >= 0 && Uri.parse(list.getItemAtIndex(target).url).path.orEmpty().trimEnd('/') == "/chats") target--
            }
            if (target >= 0) {
                webView.goBackOrForward(target - list.currentIndex)
            } else {
                super.onBackPressed()
            }
        } else {
            super.onBackPressed()
        }
    }

    private fun isAuthPage(url: String?): Boolean {
        val path = try { Uri.parse(url).path.orEmpty().trimEnd('/') } catch (e: Exception) { "" }
        return listOf(LOGIN_PATH, "/register", "/signup").any { path == it || path.startsWith("$it/") }
    }

    override fun onResume() {
        super.onResume()
        // После нативного чата обновляем список переписок (последнее сообщение, счётчики).
        if (reloadChatsOnResume) {
            reloadChatsOnResume = false
            if (nativeSection != NativeSection.CHATS) webView.reload()
        }
        if (nativeSection != null) startNativeLoading()
    }

    override fun onPause() {
        super.onPause()
        stopNativeControllers()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // Если разрешение на камеру только что выдано, повторный вызов onShowFileChooser
        // на стороне WebView предложит выбор камеры/галереи снова.
    }

    override fun onDestroy() {
        loginController.destroy()
        chatsController.destroy()
        friendsController.destroy()
        communitiesController.destroy()
        musicController.destroy()
        feedController.destroy()
        postController.destroy()
        profileController.destroy()
        portController.destroy()
        notifsController.destroy()
        settingsController.destroy()
        siteApi.destroy()
        paymentWebView?.let { it.stopLoading(); it.destroy() }
        paymentWebView = null
        webView.destroy()
        super.onDestroy()
    }
}
